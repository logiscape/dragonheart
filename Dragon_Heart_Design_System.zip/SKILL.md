---
name: dragon-heart-design
description: Use this skill to generate well-branded interfaces and assets for Dragon Heart, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping a warm, personal AI-character conversation app.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Orientation

- **The one rule:** Dragon Heart is a *relationship*, not a tool. Write and design as if the user is *with a person* — never operating a machine. No "How can I assist you?", no regenerate/copy affordances in the foreground, no emoji. See README §3 (Content fundamentals) for voice.
- **Aesthetic:** "candlelit hearthside" — warm dark, firelight ember, dragon-heart garnet, aged parchment, literary serifs, breathing motion. README §2 & §4.
- **Tokens:** link `styles.css` (it `@import`s everything in `tokens/`). Use CSS custom properties — `--surface-base`, `--accent` (ember), `--heart` (garnet), `--text-primary`, `--font-display/serif/sans/mono`, `--glow-ember`, `--radius-lg`, etc.
- **Fonts:** Cormorant Garamond (display), Spectral (reading), Hanken Grotesk (UI), JetBrains Mono (studio) — from Google Fonts.
- **Components:** React primitives in `components/`. In built HTML, load `_ds_bundle.js` and read them from `window.DragonHeartDesignSystem_1cfd7f`. Each component has a `.prompt.md` with usage.
- **Assets:** `assets/` (logo, fleuron, hearth backdrop). Icons: Lucide line set.
- **Reference build:** `ui_kits/dragon-heart/` is a full interactive recreation — read it to see the components composed into real screens.

When in doubt: more warmth, more restraint, let the interface recede.
