/* @ds-bundle: {"format":3,"namespace":"DragonHeartDesignSystem_1cfd7f","components":[{"name":"MessageBubble","sourcePath":"components/chat/MessageBubble.jsx"},{"name":"PresenceIndicator","sourcePath":"components/chat/PresenceIndicator.jsx"},{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Ornament","sourcePath":"components/core/Ornament.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/chat/MessageBubble.jsx":"22677e30d526","components/chat/PresenceIndicator.jsx":"300594b8b37f","components/core/Avatar.jsx":"0ee641b49f6a","components/core/Badge.jsx":"d53d72c6c337","components/core/Button.jsx":"653f89a6b58a","components/core/Card.jsx":"5d477d80571a","components/core/IconButton.jsx":"56ee2a8b8544","components/core/Ornament.jsx":"8a43b3801b10","components/core/Tag.jsx":"1b1b19ea1f96","components/feedback/Dialog.jsx":"ecfc3dcf0fe8","components/feedback/Toast.jsx":"5a80eaac473b","components/feedback/Tooltip.jsx":"6b565b909835","components/forms/Checkbox.jsx":"617d5a1bc6c0","components/forms/Input.jsx":"06022e6adfc2","components/forms/Select.jsx":"67247f38d810","components/forms/Switch.jsx":"27532761e598","components/forms/Textarea.jsx":"ee4e4d713051","components/navigation/Tabs.jsx":"3b5376babd2c","ui_kits/dragon-heart/Conversation.jsx":"bf2c6f3cad11","ui_kits/dragon-heart/Hall.jsx":"75897e4f35b8","ui_kits/dragon-heart/Icons.jsx":"e88f1986ffe2","ui_kits/dragon-heart/Sidebar.jsx":"79721eeeb84b","ui_kits/dragon-heart/Studio.jsx":"323cd7896fe8","ui_kits/dragon-heart/Welcome.jsx":"47c8629c77a7","ui_kits/dragon-heart/data.js":"ab8db25ba2e1"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DragonHeartDesignSystem_1cfd7f = window.DragonHeartDesignSystem_1cfd7f || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/chat/MessageBubble.jsx
try { (() => {
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-message", `
  .dh-msg{ display:flex; gap:var(--space-4); max-width:var(--measure-reading); }
  .dh-msg__col{ flex:1; min-width:0; }
  .dh-msg__name{
    font-family:var(--font-sans); font-size:var(--text-2xs); font-weight:var(--weight-semibold);
    letter-spacing:var(--tracking-caps); text-transform:uppercase; color:var(--ember-300);
    margin:0 0 .3rem;
  }
  .dh-msg__time{ color:var(--text-faint); letter-spacing:var(--tracking-wide); margin-left:.6rem; }

  /* The character speaks: flowing serif prose, no bubble. */
  .dh-msg--character .dh-msg__text{
    font-family:var(--font-serif); font-size:var(--type-body-size);
    line-height:var(--leading-relaxed); color:var(--text-primary); margin:0;
  }
  .dh-msg--character .dh-msg__text + .dh-msg__text{ margin-top:.85em; }
  .dh-msg--dropcap .dh-msg__text:first-of-type::first-letter{
    font-family:var(--font-display); font-weight:var(--weight-medium);
    font-size:3.1em; line-height:.84; float:left; padding:.06em .12em 0 0; color:var(--ember-400);
  }

  /* The user speaks: a quiet right-aligned well. */
  .dh-msg--user{ margin-left:auto; flex-direction:row-reverse; }
  .dh-msg--user .dh-msg__col{ display:flex; flex-direction:column; align-items:flex-end; }
  .dh-msg--user .dh-msg__bubble{
    background:var(--surface-card); border:1px solid var(--border-subtle);
    border-radius:var(--radius-lg) var(--radius-lg) var(--radius-xs) var(--radius-lg);
    padding:.7rem 1.05rem; color:var(--text-secondary);
    font-family:var(--font-serif); font-size:var(--text-md); line-height:var(--leading-normal);
    box-shadow:var(--shadow-sm);
  }
`);
function MessageBubble({
  from = "character",
  name = null,
  time = null,
  avatar = null,
  dropcap = false,
  children,
  className = ""
}) {
  const isUser = from === "user";
  const cls = ["dh-msg", isUser ? "dh-msg--user" : "dh-msg--character", dropcap && !isUser ? "dh-msg--dropcap" : "", className].filter(Boolean).join(" ");
  const paras = typeof children === "string" ? children.split(/\n{2,}/) : null;
  return /*#__PURE__*/React.createElement("div", {
    className: cls
  }, avatar ? /*#__PURE__*/React.createElement("div", {
    className: "dh-msg__avatar"
  }, avatar) : null, /*#__PURE__*/React.createElement("div", {
    className: "dh-msg__col"
  }, !isUser && (name || time) ? /*#__PURE__*/React.createElement("p", {
    className: "dh-msg__name"
  }, name, time ? /*#__PURE__*/React.createElement("span", {
    className: "dh-msg__time"
  }, time) : null) : null, isUser ? /*#__PURE__*/React.createElement("div", {
    className: "dh-msg__bubble"
  }, children) : paras ? paras.map((p, i) => /*#__PURE__*/React.createElement("p", {
    key: i,
    className: "dh-msg__text"
  }, p)) : /*#__PURE__*/React.createElement("div", {
    className: "dh-msg__text"
  }, children)));
}
Object.assign(__ds_scope, { MessageBubble });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chat/MessageBubble.jsx", error: String((e && e.message) || e) }); }

// components/chat/PresenceIndicator.jsx
try { (() => {
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-presence", `
  .dh-presence{
    display:inline-flex; align-items:center; gap:.6rem;
    font-family:var(--font-sans); font-size:var(--text-sm); color:var(--text-muted);
  }
  .dh-presence__orb{
    width:.7rem; height:.7rem; border-radius:var(--radius-full); flex:none;
    background:var(--_mood, var(--accent)); position:relative;
  }
  .dh-presence--present .dh-presence__orb{ box-shadow:0 0 10px -1px var(--_mood, var(--accent)); }
  .dh-presence--present .dh-presence__orb::after{
    content:""; position:absolute; inset:-4px; border-radius:var(--radius-full);
    border:1px solid var(--_mood, var(--accent)); animation:dh-breathe var(--dur-breath) var(--ease-soft) infinite;
  }
  .dh-presence--dormant .dh-presence__orb{ background:var(--taupe-400); }
  .dh-presence--away .dh-presence__orb{ background:var(--ember-400); }
  .dh-presence__label{ color:var(--text-secondary); }
  .dh-presence__label em{ font-style:italic; color:var(--text-muted); }

  .dh-presence__dots{ display:inline-flex; gap:.22rem; align-items:center; }
  .dh-presence__dots span{
    width:.34rem; height:.34rem; border-radius:var(--radius-full);
    background:var(--_mood, var(--accent)); animation:dh-flicker 1.4s var(--ease-soft) infinite;
  }
  .dh-presence__dots span:nth-child(2){ animation-delay:.2s; }
  .dh-presence__dots span:nth-child(3){ animation-delay:.4s; }
  @media (prefers-reduced-motion: reduce){
    .dh-presence__orb::after, .dh-presence__dots span{ animation:none; }
  }
`);
const MOODS = {
  ember: "var(--accent)",
  heart: "var(--heart)",
  moss: "var(--moss-400)",
  arcane: "var(--arcane-400)"
};
function PresenceIndicator({
  name = "",
  state = "present",
  mood = "ember",
  className = "",
  style = {}
}) {
  const vars = {
    "--_mood": MOODS[mood] || mood,
    ...style
  };
  const labels = {
    present: /*#__PURE__*/React.createElement("span", {
      className: "dh-presence__label"
    }, name ? /*#__PURE__*/React.createElement("strong", null, name) : "They", " ", name ? "is here" : "are here"),
    thinking: /*#__PURE__*/React.createElement("span", {
      className: "dh-presence__label"
    }, /*#__PURE__*/React.createElement("em", null, name ? `${name} is gathering their thoughts` : "gathering thoughts")),
    away: /*#__PURE__*/React.createElement("span", {
      className: "dh-presence__label"
    }, name ? `${name} stepped away` : "away"),
    dormant: /*#__PURE__*/React.createElement("span", {
      className: "dh-presence__label"
    }, name ? `${name} is resting` : "resting")
  };
  return /*#__PURE__*/React.createElement("span", {
    className: ["dh-presence", `dh-presence--${state}`, className].filter(Boolean).join(" "),
    style: vars
  }, state === "thinking" ? /*#__PURE__*/React.createElement("span", {
    className: "dh-presence__dots",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement("span", null)) : /*#__PURE__*/React.createElement("span", {
    className: "dh-presence__orb",
    "aria-hidden": "true"
  }), labels[state]);
}
Object.assign(__ds_scope, { PresenceIndicator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chat/PresenceIndicator.jsx", error: String((e && e.message) || e) }); }

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-avatar", `
  .dh-avatar{
    --_size:3rem; --_mood:var(--accent);
    position:relative; display:inline-flex; align-items:center; justify-content:center;
    width:var(--_size); height:var(--_size); flex:none;
  }
  .dh-avatar__face{
    position:relative; width:100%; height:100%; border-radius:var(--radius-full);
    overflow:hidden; display:flex; align-items:center; justify-content:center;
    background:
      radial-gradient(120% 120% at 30% 20%, rgba(243,194,119,0.22), transparent 60%),
      linear-gradient(155deg, var(--ink-600), var(--ink-850));
    border:1px solid var(--border-soft);
    color:var(--parch-100); font-family:var(--font-display);
    font-weight:var(--weight-medium); line-height:1;
    box-shadow:var(--shadow-sm);
  }
  .dh-avatar__face img{ width:100%; height:100%; object-fit:cover; display:block; }
  .dh-avatar__mono{ font-size:calc(var(--_size) * 0.42); padding-top:.04em; letter-spacing:.01em; }

  /* presence ring */
  .dh-avatar--ring .dh-avatar__face{ border-color:color-mix(in srgb, var(--_mood) 70%, transparent); }
  .dh-avatar--ring::after{
    content:""; position:absolute; inset:-3px; border-radius:var(--radius-full);
    border:1.5px solid var(--_mood); opacity:.55; pointer-events:none;
  }
  .dh-avatar--breathing::after{ animation:dh-breathe var(--dur-breath) var(--ease-soft) infinite; box-shadow:0 0 18px -4px var(--_mood); }
  @media (prefers-reduced-motion: reduce){ .dh-avatar--breathing::after{ animation:none; } }

  /* status pip */
  .dh-avatar__pip{
    position:absolute; right:2%; bottom:2%; width:30%; height:30%;
    min-width:9px; min-height:9px; border-radius:var(--radius-full);
    border:2px solid var(--surface-base); background:var(--taupe-400);
  }
  .dh-avatar__pip--present{ background:var(--moss-400); box-shadow:0 0 8px -1px var(--moss-400); }
  .dh-avatar__pip--away{ background:var(--ember-400); }
  .dh-avatar__pip--dormant{ background:var(--taupe-400); }
`);
const SIZES = {
  xs: "1.75rem",
  sm: "2.25rem",
  md: "3rem",
  lg: "4rem",
  xl: "5.5rem",
  "2xl": "8rem"
};
const MOODS = {
  ember: "var(--accent)",
  heart: "var(--heart)",
  moss: "var(--moss-400)",
  arcane: "var(--arcane-400)"
};
function initials(name) {
  if (!name) return "·";
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] || "") + (parts.length > 1 ? parts[parts.length - 1][0] : "")).toUpperCase();
}
function Avatar({
  src = null,
  name = "",
  size = "md",
  mood = "ember",
  ring = false,
  breathing = false,
  status = "none",
  className = "",
  style = {},
  ...rest
}) {
  const cls = ["dh-avatar", ring || breathing ? "dh-avatar--ring" : "", breathing ? "dh-avatar--breathing" : "", className].filter(Boolean).join(" ");
  const vars = {
    "--_size": SIZES[size] || size,
    "--_mood": MOODS[mood] || mood,
    ...style
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls,
    style: vars
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "dh-avatar__face"
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name
  }) : /*#__PURE__*/React.createElement("span", {
    className: "dh-avatar__mono"
  }, initials(name))), status !== "none" ? /*#__PURE__*/React.createElement("span", {
    className: `dh-avatar__pip dh-avatar__pip--${status}`,
    "aria-hidden": "true"
  }) : null);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-badge", `
  .dh-badge{
    display:inline-flex; align-items:center; gap:.4em;
    font-family:var(--font-sans); font-weight:var(--weight-semibold);
    font-size:var(--text-2xs); letter-spacing:var(--tracking-wide);
    text-transform:uppercase; line-height:1;
    padding:.34em .68em; border-radius:var(--radius-full);
    border:1px solid transparent; white-space:nowrap;
  }
  .dh-badge__dot{ width:.5em; height:.5em; border-radius:var(--radius-full); background:currentColor; }

  .dh-badge--neutral{ background:rgba(241,232,214,0.07); color:var(--text-secondary); border-color:var(--border-soft); }
  .dh-badge--ember{ background:var(--accent-soft); color:var(--ember-200); border-color:var(--accent-line); }
  .dh-badge--heart{ background:var(--heart-soft); color:var(--garnet-300); border-color:rgba(186,70,50,0.32); }
  .dh-badge--moss{ background:var(--success-soft); color:var(--moss-300); border-color:rgba(135,160,109,0.32); }
  .dh-badge--arcane{ background:var(--info-soft); color:var(--arcane-300); border-color:rgba(120,145,168,0.32); }

  .dh-badge--solid.dh-badge--ember{ background:var(--accent); color:var(--text-on-ember); border-color:transparent; }
  .dh-badge--solid.dh-badge--heart{ background:var(--heart); color:var(--parch-50); border-color:transparent; }
  .dh-badge--solid.dh-badge--moss{ background:var(--moss-500); color:var(--parch-50); border-color:transparent; }
`);
function Badge({
  children,
  tone = "neutral",
  solid = false,
  dot = false,
  className = "",
  ...rest
}) {
  const cls = ["dh-badge", `dh-badge--${tone}`, solid ? "dh-badge--solid" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), dot ? /*#__PURE__*/React.createElement("span", {
    className: "dh-badge__dot",
    "aria-hidden": "true"
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Inject a component's CSS once. Plain DOM, no CSS-in-JS lib. */
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-button", `
  .dh-btn{
    --_bg: var(--accent); --_fg: var(--text-on-ember); --_bd: transparent; --_glow: none;
    display:inline-flex; align-items:center; justify-content:center; gap:.55em;
    font-family:var(--font-sans); font-weight:var(--weight-semibold);
    letter-spacing:.01em; line-height:1; white-space:nowrap; cursor:pointer;
    border:1px solid var(--_bd); background:var(--_bg); color:var(--_fg);
    border-radius:var(--radius-md); box-shadow:var(--_glow);
    transition:var(--transition-control); -webkit-font-smoothing:antialiased;
    user-select:none;
  }
  .dh-btn:focus-visible{ outline:none; box-shadow:var(--ring-focus); }
  .dh-btn:active{ transform:translateY(1px) scale(.99); }
  .dh-btn[disabled]{ cursor:not-allowed; opacity:.42; box-shadow:none; transform:none; }

  .dh-btn--sm{ font-size:var(--text-sm); padding:.5rem .85rem; }
  .dh-btn--md{ font-size:var(--text-md); padding:.7rem 1.25rem; }
  .dh-btn--lg{ font-size:var(--text-lg); padding:.9rem 1.7rem; border-radius:var(--radius-lg); }
  .dh-btn--block{ display:flex; width:100%; }
  .dh-btn--pill{ border-radius:var(--radius-full); }

  .dh-btn--primary{ --_bg:var(--accent); --_fg:var(--text-on-ember); --_glow:var(--glow-ember-sm); }
  .dh-btn--primary:hover:not([disabled]){ --_bg:var(--accent-hover); box-shadow:var(--glow-ember); }
  .dh-btn--primary:active:not([disabled]){ --_bg:var(--accent-press); }

  .dh-btn--heart{ --_bg:var(--heart); --_fg:var(--parch-50); --_glow:var(--glow-heart); }
  .dh-btn--heart:hover:not([disabled]){ --_bg:var(--garnet-400); }

  .dh-btn--secondary{ --_bg:transparent; --_fg:var(--text-primary); --_bd:var(--border-gilt); }
  .dh-btn--secondary:hover:not([disabled]){ --_bg:var(--accent-soft); --_bd:var(--accent-line); --_fg:var(--ember-200); }

  .dh-btn--ghost{ --_bg:transparent; --_fg:var(--text-secondary); --_bd:transparent; }
  .dh-btn--ghost:hover:not([disabled]){ --_bg:rgba(241,232,214,0.06); --_fg:var(--text-primary); }

  .dh-btn__icon{ display:inline-flex; align-items:center; }
  .dh-btn__icon svg{ width:1.15em; height:1.15em; display:block; }
`);
function Button({
  children,
  variant = "primary",
  size = "md",
  block = false,
  pill = false,
  leftIcon = null,
  rightIcon = null,
  disabled = false,
  type = "button",
  className = "",
  ...rest
}) {
  const cls = ["dh-btn", `dh-btn--${variant}`, `dh-btn--${size}`, block ? "dh-btn--block" : "", pill ? "dh-btn--pill" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: cls,
    disabled: disabled
  }, rest), leftIcon ? /*#__PURE__*/React.createElement("span", {
    className: "dh-btn__icon"
  }, leftIcon) : null, children, rightIcon ? /*#__PURE__*/React.createElement("span", {
    className: "dh-btn__icon"
  }, rightIcon) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-card", `
  .dh-card{
    background:var(--surface-card); color:var(--text-primary);
    border:1px solid var(--border-subtle); border-radius:var(--radius-lg);
    box-shadow:var(--shadow-md); transition:var(--transition-control);
    overflow:hidden; position:relative;
  }
  .dh-card--pad{ padding:var(--pad-card); }
  .dh-card--raised{ background:var(--surface-raised); box-shadow:var(--shadow-lg); }
  .dh-card--parchment{
    background:var(--surface-parchment); color:var(--text-on-parch);
    border-color:rgba(120,90,40,0.18);
  }
  .dh-card--interactive{ cursor:pointer; }
  .dh-card--interactive:hover{
    border-color:var(--border-gilt); box-shadow:var(--shadow-lg), var(--glow-soft);
    transform:translateY(-2px);
  }
  .dh-card--glow{ box-shadow:var(--shadow-md), var(--glow-ember-sm); border-color:var(--accent-line); }
  .dh-card__gilt{
    position:absolute; inset:0; border-radius:inherit; pointer-events:none;
    border:1px solid var(--border-gilt); opacity:.5;
    -webkit-mask:linear-gradient(#000,transparent 60%);
            mask:linear-gradient(#000,transparent 60%);
  }
`);
function Card({
  children,
  variant = "default",
  padded = true,
  interactive = false,
  glow = false,
  gilt = false,
  className = "",
  ...rest
}) {
  const cls = ["dh-card", variant !== "default" ? `dh-card--${variant}` : "", padded ? "dh-card--pad" : "", interactive ? "dh-card--interactive" : "", glow ? "dh-card--glow" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), gilt ? /*#__PURE__*/React.createElement("span", {
    className: "dh-card__gilt",
    "aria-hidden": "true"
  }) : null, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-iconbutton", `
  .dh-iconbtn{
    --_bg:transparent; --_fg:var(--text-secondary); --_bd:transparent;
    display:inline-flex; align-items:center; justify-content:center;
    border:1px solid var(--_bd); background:var(--_bg); color:var(--_fg);
    border-radius:var(--radius-md); cursor:pointer;
    transition:var(--transition-control); -webkit-font-smoothing:antialiased;
  }
  .dh-iconbtn svg{ width:1.25em; height:1.25em; display:block; }
  .dh-iconbtn:focus-visible{ outline:none; box-shadow:var(--ring-focus); }
  .dh-iconbtn:active:not([disabled]){ transform:scale(.92); }
  .dh-iconbtn[disabled]{ opacity:.4; cursor:not-allowed; }

  .dh-iconbtn--sm{ width:2rem; height:2rem; font-size:.95rem; }
  .dh-iconbtn--md{ width:2.5rem; height:2.5rem; font-size:1.1rem; }
  .dh-iconbtn--lg{ width:3rem; height:3rem; font-size:1.3rem; }
  .dh-iconbtn--round{ border-radius:var(--radius-full); }

  .dh-iconbtn--ghost:hover:not([disabled]){ --_bg:rgba(241,232,214,0.06); --_fg:var(--text-primary); }
  .dh-iconbtn--solid{ --_bg:var(--surface-card); --_fg:var(--text-primary); --_bd:var(--border-soft); }
  .dh-iconbtn--solid:hover:not([disabled]){ --_bg:var(--surface-overlay); --_bd:var(--border-gilt); }
  .dh-iconbtn--ember{ --_bg:var(--accent); --_fg:var(--text-on-ember); box-shadow:var(--glow-ember-sm); }
  .dh-iconbtn--ember:hover:not([disabled]){ --_bg:var(--accent-hover); box-shadow:var(--glow-ember); }
`);
function IconButton({
  children,
  label,
  variant = "ghost",
  size = "md",
  round = false,
  disabled = false,
  className = "",
  ...rest
}) {
  const cls = ["dh-iconbtn", `dh-iconbtn--${variant}`, `dh-iconbtn--${size}`, round ? "dh-iconbtn--round" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: cls,
    "aria-label": label,
    title: label,
    disabled: disabled
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Ornament.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-ornament", `
  .dh-ornament{
    display:flex; align-items:center; gap:var(--space-4);
    color:var(--accent); width:100%;
  }
  .dh-ornament__rule{
    flex:1; height:1px; border:none;
    background:linear-gradient(90deg, transparent, var(--border-gilt));
  }
  .dh-ornament__rule--right{ background:linear-gradient(90deg, var(--border-gilt), transparent); }
  .dh-ornament__mark{ display:flex; align-items:center; gap:.5em; }
  .dh-ornament__mark svg{ width:1.6em; height:1.9em; }
  .dh-ornament__label{
    font-family:var(--font-sans); font-weight:var(--weight-semibold);
    font-size:var(--text-2xs); letter-spacing:var(--tracking-caps);
    text-transform:uppercase; color:var(--text-muted); white-space:nowrap;
  }
  .dh-ornament__diamond{ width:5px; height:5px; background:var(--accent); transform:rotate(45deg); opacity:.8; }
`);
const Fleuron = () => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 40 48",
  fill: "none",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("g", {
  stroke: "currentColor",
  strokeOpacity: "0.7",
  strokeWidth: "1.4",
  strokeLinecap: "round"
}, /*#__PURE__*/React.createElement("path", {
  d: "M20 8 C20 16, 20 18, 20 24"
}), /*#__PURE__*/React.createElement("path", {
  d: "M20 24 C12 20, 8 14, 12 9 C16 5, 20 12, 20 18"
}), /*#__PURE__*/React.createElement("path", {
  d: "M20 24 C28 20, 32 14, 28 9 C24 5, 20 12, 20 18"
})), /*#__PURE__*/React.createElement("circle", {
  cx: "20",
  cy: "30",
  r: "2.2",
  fill: "currentColor"
}));
function Ornament({
  label = null,
  mark = "fleuron",
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ["dh-ornament", className].filter(Boolean).join(" "),
    role: "separator"
  }, rest), /*#__PURE__*/React.createElement("hr", {
    className: "dh-ornament__rule"
  }), /*#__PURE__*/React.createElement("span", {
    className: "dh-ornament__mark"
  }, mark === "fleuron" ? /*#__PURE__*/React.createElement(Fleuron, null) : /*#__PURE__*/React.createElement("span", {
    className: "dh-ornament__diamond"
  }), label ? /*#__PURE__*/React.createElement("span", {
    className: "dh-ornament__label"
  }, label) : null), /*#__PURE__*/React.createElement("hr", {
    className: "dh-ornament__rule dh-ornament__rule--right"
  }));
}
Object.assign(__ds_scope, { Ornament });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Ornament.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-tag", `
  .dh-tag{
    display:inline-flex; align-items:center; gap:.45em;
    font-family:var(--font-sans); font-size:var(--text-sm); font-weight:var(--weight-medium);
    color:var(--text-secondary); background:rgba(241,232,214,0.05);
    border:1px solid var(--border-soft); border-radius:var(--radius-full);
    padding:.36em .8em; line-height:1; transition:var(--transition-control);
  }
  .dh-tag svg{ width:1em; height:1em; }
  .dh-tag--interactive{ cursor:pointer; }
  .dh-tag--interactive:hover{ border-color:var(--border-gilt); color:var(--ember-200); background:var(--accent-soft); }
  .dh-tag--selected{ border-color:var(--accent-line); color:var(--ember-200); background:var(--accent-soft); }
  .dh-tag__remove{
    display:inline-flex; align-items:center; justify-content:center;
    margin-right:-.25em; width:1.15em; height:1.15em; border-radius:var(--radius-full);
    border:none; background:transparent; color:inherit; cursor:pointer; opacity:.65;
    font-size:1.05em; line-height:1; transition:var(--transition-control);
  }
  .dh-tag__remove:hover{ opacity:1; background:rgba(241,232,214,0.12); }
`);
function Tag({
  children,
  icon = null,
  selected = false,
  interactive = false,
  onRemove = null,
  className = "",
  ...rest
}) {
  const cls = ["dh-tag", interactive || onRemove ? "dh-tag--interactive" : "", selected ? "dh-tag--selected" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, icon) : null, children, onRemove ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "dh-tag__remove",
    "aria-label": "Remove",
    onClick: onRemove
  }, "\xD7") : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-dialog", `
  .dh-dialog__scrim{
    position:fixed; inset:0; background:var(--surface-scrim);
    backdrop-filter:blur(3px); -webkit-backdrop-filter:blur(3px);
    display:flex; align-items:center; justify-content:center; padding:var(--space-6);
    z-index:1000; animation:dh-rise var(--dur-base) var(--ease-gentle);
  }
  .dh-dialog{
    position:relative; width:100%; max-width:min(520px, 92vw);
    background:var(--surface-overlay); color:var(--text-primary);
    border:1px solid var(--border-soft); border-radius:var(--radius-xl);
    box-shadow:var(--shadow-xl), var(--glow-soft); overflow:hidden;
  }
  .dh-dialog::before{
    content:""; position:absolute; inset:0 0 auto 0; height:3px;
    background:linear-gradient(90deg, transparent, var(--accent), transparent); opacity:.7;
  }
  .dh-dialog__body{ padding:var(--space-7) var(--space-7) var(--space-6); }
  .dh-dialog__title{
    font-family:var(--font-display); font-weight:var(--weight-medium);
    font-size:var(--text-2xl); line-height:var(--leading-snug); margin:0 0 .4rem;
    color:var(--text-primary);
  }
  .dh-dialog__desc{
    font-family:var(--font-serif); font-size:var(--text-lg);
    line-height:var(--leading-relaxed); color:var(--text-secondary); margin:0;
  }
  .dh-dialog__footer{
    display:flex; justify-content:flex-end; gap:var(--space-3);
    padding:var(--space-5) var(--space-7); border-top:1px solid var(--border-subtle);
    background:rgba(0,0,0,0.15);
  }
  .dh-dialog__close{
    position:absolute; top:var(--space-4); right:var(--space-4);
    width:2rem; height:2rem; border-radius:var(--radius-full);
    border:none; background:transparent; color:var(--text-muted); cursor:pointer;
    font-size:1.4rem; line-height:1; transition:var(--transition-control);
  }
  .dh-dialog__close:hover{ background:rgba(241,232,214,0.08); color:var(--text-primary); }
`);
function Dialog({
  open = false,
  title = null,
  description = null,
  onClose,
  children,
  footer = null
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "dh-dialog__scrim",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "dh-dialog",
    role: "dialog",
    "aria-modal": "true",
    onClick: e => e.stopPropagation()
  }, onClose ? /*#__PURE__*/React.createElement("button", {
    className: "dh-dialog__close",
    "aria-label": "Close",
    onClick: onClose
  }, "\xD7") : null, /*#__PURE__*/React.createElement("div", {
    className: "dh-dialog__body"
  }, title ? /*#__PURE__*/React.createElement("h2", {
    className: "dh-dialog__title"
  }, title) : null, description ? /*#__PURE__*/React.createElement("p", {
    className: "dh-dialog__desc"
  }, description) : null, children), footer ? /*#__PURE__*/React.createElement("div", {
    className: "dh-dialog__footer"
  }, footer) : null));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-toast", `
  .dh-toast{
    display:flex; align-items:flex-start; gap:.85rem;
    min-width:280px; max-width:420px;
    background:var(--surface-overlay); border:1px solid var(--border-soft);
    border-left:3px solid var(--_accent, var(--accent));
    border-radius:var(--radius-md); box-shadow:var(--shadow-lg);
    padding:var(--space-4) var(--space-5);
    font-family:var(--font-sans); animation:dh-rise var(--dur-base) var(--ease-gentle);
  }
  .dh-toast--ember{ --_accent:var(--accent); }
  .dh-toast--heart{ --_accent:var(--heart); }
  .dh-toast--moss{ --_accent:var(--moss-400); }
  .dh-toast--arcane{ --_accent:var(--arcane-400); }
  .dh-toast__icon{ color:var(--_accent, var(--accent)); display:inline-flex; margin-top:.1rem; }
  .dh-toast__icon svg{ width:1.25rem; height:1.25rem; }
  .dh-toast__body{ flex:1; min-width:0; }
  .dh-toast__title{ font-size:var(--text-md); font-weight:var(--weight-semibold); color:var(--text-primary); margin:0 0 .15rem; }
  .dh-toast__msg{ font-size:var(--text-sm); color:var(--text-secondary); margin:0; line-height:var(--leading-snug); }
  .dh-toast__close{
    border:none; background:transparent; color:var(--text-faint); cursor:pointer;
    font-size:1.1rem; line-height:1; padding:.1rem; transition:var(--transition-control);
  }
  .dh-toast__close:hover{ color:var(--text-primary); }
`);
function Toast({
  tone = "ember",
  title = null,
  icon = null,
  onClose,
  children,
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ["dh-toast", `dh-toast--${tone}`, className].filter(Boolean).join(" "),
    role: "status"
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    className: "dh-toast__icon"
  }, icon) : null, /*#__PURE__*/React.createElement("div", {
    className: "dh-toast__body"
  }, title ? /*#__PURE__*/React.createElement("p", {
    className: "dh-toast__title"
  }, title) : null, children ? /*#__PURE__*/React.createElement("p", {
    className: "dh-toast__msg"
  }, children) : null), onClose ? /*#__PURE__*/React.createElement("button", {
    className: "dh-toast__close",
    "aria-label": "Dismiss",
    onClick: onClose
  }, "\xD7") : null);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-tooltip", `
  .dh-tooltip{ position:relative; display:inline-flex; }
  .dh-tooltip__bubble{
    position:absolute; z-index:50; left:50%; transform:translateX(-50%) translateY(4px);
    bottom:calc(100% + 8px); white-space:nowrap; pointer-events:none;
    background:var(--surface-overlay); color:var(--text-primary);
    border:1px solid var(--border-soft); border-radius:var(--radius-sm);
    padding:.35rem .6rem; font-family:var(--font-sans); font-size:var(--text-xs);
    box-shadow:var(--shadow-md); opacity:0; transition:opacity var(--dur-quick) var(--ease-soft), transform var(--dur-quick) var(--ease-gentle);
  }
  .dh-tooltip__bubble::after{
    content:""; position:absolute; top:100%; left:50%; transform:translateX(-50%);
    border:5px solid transparent; border-top-color:var(--surface-overlay);
  }
  .dh-tooltip:hover .dh-tooltip__bubble, .dh-tooltip:focus-within .dh-tooltip__bubble{
    opacity:1; transform:translateX(-50%) translateY(0);
  }
  .dh-tooltip--bottom .dh-tooltip__bubble{ bottom:auto; top:calc(100% + 8px); transform:translateX(-50%) translateY(-4px); }
  .dh-tooltip--bottom .dh-tooltip__bubble::after{ top:auto; bottom:100%; border-top-color:transparent; border-bottom-color:var(--surface-overlay); }
  .dh-tooltip--bottom:hover .dh-tooltip__bubble{ transform:translateX(-50%) translateY(0); }
`);
function Tooltip({
  label,
  placement = "top",
  children,
  className = ""
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: ["dh-tooltip", `dh-tooltip--${placement}`, className].filter(Boolean).join(" ")
  }, children, /*#__PURE__*/React.createElement("span", {
    className: "dh-tooltip__bubble",
    role: "tooltip"
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-checkbox", `
  .dh-checkbox{
    display:inline-flex; align-items:center; gap:.65rem; cursor:pointer;
    font-family:var(--font-sans); font-size:var(--text-md); color:var(--text-secondary);
    user-select:none;
  }
  .dh-checkbox input{ position:absolute; opacity:0; width:0; height:0; }
  .dh-checkbox__box{
    width:1.25rem; height:1.25rem; flex:none; border-radius:var(--radius-xs);
    border:1px solid var(--border-strong); background:var(--surface-inset);
    display:inline-flex; align-items:center; justify-content:center;
    transition:var(--transition-control); box-shadow:var(--shadow-inset);
    color:var(--text-on-ember);
  }
  .dh-checkbox__box svg{ width:.85rem; height:.85rem; opacity:0; transform:scale(.6); transition:var(--transition-control); }
  .dh-checkbox:hover .dh-checkbox__box{ border-color:var(--border-gilt); }
  .dh-checkbox input:checked + .dh-checkbox__box{ background:var(--accent); border-color:var(--accent); box-shadow:var(--glow-ember-sm); }
  .dh-checkbox input:checked + .dh-checkbox__box svg{ opacity:1; transform:scale(1); }
  .dh-checkbox input:focus-visible + .dh-checkbox__box{ box-shadow:var(--ring-focus); }
  .dh-checkbox input:disabled ~ *{ opacity:.45; }
  .dh-checkbox--disabled{ cursor:not-allowed; }
`);
function Checkbox({
  label = null,
  checked,
  defaultChecked,
  disabled = false,
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: ["dh-checkbox", disabled ? "dh-checkbox--disabled" : "", className].filter(Boolean).join(" ")
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    defaultChecked: defaultChecked,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "dh-checkbox__box"
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M5 13l4 4L19 7",
    stroke: "currentColor",
    strokeWidth: "2.6",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-field", `
  .dh-field{ display:flex; flex-direction:column; gap:.4rem; font-family:var(--font-sans); }
  .dh-field__label{
    font-size:var(--text-2xs); font-weight:var(--weight-semibold);
    letter-spacing:var(--tracking-caps); text-transform:uppercase; color:var(--text-muted);
  }
  .dh-field__wrap{
    display:flex; align-items:center; gap:.6rem;
    background:var(--surface-inset); border:1px solid var(--border-soft);
    border-radius:var(--radius-md); padding:0 .85rem;
    box-shadow:var(--shadow-inset); transition:var(--transition-control);
  }
  .dh-field__wrap:focus-within{ border-color:var(--accent); box-shadow:var(--shadow-inset), var(--glow-ember-sm); }
  .dh-field__wrap--error{ border-color:var(--danger); }
  .dh-field__icon{ display:inline-flex; color:var(--text-muted); }
  .dh-field__icon svg{ width:1.15em; height:1.15em; display:block; }
  .dh-field__input{
    flex:1; min-width:0; background:transparent; border:none; outline:none;
    color:var(--text-primary); font-family:var(--font-serif); font-size:var(--text-md);
    padding:.7rem 0;
  }
  .dh-field__input::placeholder{ color:var(--text-faint); }
  .dh-field__input:disabled{ color:var(--text-faint); cursor:not-allowed; }
  .dh-field__hint{ font-size:var(--text-xs); color:var(--text-faint); }
  .dh-field__hint--error{ color:var(--garnet-300); }
`);
function Input({
  label = null,
  hint = null,
  error = null,
  leftIcon = null,
  rightIcon = null,
  id,
  className = "",
  ...rest
}) {
  const fieldId = id || (label ? `dh-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  return /*#__PURE__*/React.createElement("div", {
    className: ["dh-field", className].filter(Boolean).join(" ")
  }, label ? /*#__PURE__*/React.createElement("label", {
    className: "dh-field__label",
    htmlFor: fieldId
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    className: ["dh-field__wrap", error ? "dh-field__wrap--error" : ""].filter(Boolean).join(" ")
  }, leftIcon ? /*#__PURE__*/React.createElement("span", {
    className: "dh-field__icon"
  }, leftIcon) : null, /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    className: "dh-field__input"
  }, rest)), rightIcon ? /*#__PURE__*/React.createElement("span", {
    className: "dh-field__icon"
  }, rightIcon) : null), error ? /*#__PURE__*/React.createElement("span", {
    className: "dh-field__hint dh-field__hint--error"
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    className: "dh-field__hint"
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-select", `
  .dh-select-field{ display:flex; flex-direction:column; gap:.4rem; font-family:var(--font-sans); }
  .dh-select-field__label{
    font-size:var(--text-2xs); font-weight:var(--weight-semibold);
    letter-spacing:var(--tracking-caps); text-transform:uppercase; color:var(--text-muted);
  }
  .dh-select{ position:relative; display:flex; align-items:center; }
  .dh-select select{
    appearance:none; -webkit-appearance:none; width:100%;
    background:var(--surface-inset); border:1px solid var(--border-soft);
    border-radius:var(--radius-md); box-shadow:var(--shadow-inset);
    color:var(--text-primary); font-family:var(--font-sans); font-size:var(--text-md);
    padding:.7rem 2.4rem .7rem 1rem; outline:none; cursor:pointer;
    transition:var(--transition-control);
  }
  .dh-select select:focus{ border-color:var(--accent); box-shadow:var(--shadow-inset), var(--glow-ember-sm); }
  .dh-select select:disabled{ color:var(--text-faint); cursor:not-allowed; }
  .dh-select__chev{
    position:absolute; right:.95rem; pointer-events:none; color:var(--text-muted);
    width:1rem; height:1rem;
  }
  .dh-select option{ background:var(--surface-overlay); color:var(--text-primary); }
`);
function Select({
  label = null,
  options = [],
  children,
  id,
  className = "",
  ...rest
}) {
  const fieldId = id || (label ? `dh-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  const control = /*#__PURE__*/React.createElement("div", {
    className: "dh-select"
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: fieldId,
    className: className
  }, rest), options.length ? options.map(o => typeof o === "string" ? /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o) : /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label)) : children), /*#__PURE__*/React.createElement("svg", {
    className: "dh-select__chev",
    viewBox: "0 0 24 24",
    fill: "none",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M6 9l6 6 6-6",
    stroke: "currentColor",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
  if (!label) return control;
  return /*#__PURE__*/React.createElement("div", {
    className: "dh-select-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "dh-select-field__label",
    htmlFor: fieldId
  }, label), control);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-switch", `
  .dh-switch{
    display:inline-flex; align-items:center; gap:.7rem; cursor:pointer;
    font-family:var(--font-sans); font-size:var(--text-md); color:var(--text-secondary);
    user-select:none;
  }
  .dh-switch input{ position:absolute; opacity:0; width:0; height:0; }
  .dh-switch__track{
    width:2.6rem; height:1.5rem; flex:none; border-radius:var(--radius-full);
    background:var(--surface-inset); border:1px solid var(--border-strong);
    box-shadow:var(--shadow-inset); transition:var(--transition-control); position:relative;
  }
  .dh-switch__thumb{
    position:absolute; top:50%; left:3px; transform:translateY(-50%);
    width:1.05rem; height:1.05rem; border-radius:var(--radius-full);
    background:var(--taupe-200); transition:var(--transition-control);
  }
  .dh-switch input:checked + .dh-switch__track{ background:var(--accent); border-color:var(--accent); box-shadow:var(--glow-ember-sm); }
  .dh-switch input:checked + .dh-switch__track .dh-switch__thumb{ left:calc(100% - 1.05rem - 3px); background:var(--ink-950); }
  .dh-switch input:focus-visible + .dh-switch__track{ box-shadow:var(--ring-focus); }
  .dh-switch input:disabled ~ *{ opacity:.45; }
`);
function Switch({
  label = null,
  checked,
  defaultChecked,
  disabled = false,
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: ["dh-switch", className].filter(Boolean).join(" ")
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    role: "switch",
    checked: checked,
    defaultChecked: defaultChecked,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "dh-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dh-switch__thumb"
  })), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-textarea", `
  .dh-textarea-field{ display:flex; flex-direction:column; gap:.4rem; font-family:var(--font-sans); }
  .dh-textarea-field__label{
    font-size:var(--text-2xs); font-weight:var(--weight-semibold);
    letter-spacing:var(--tracking-caps); text-transform:uppercase; color:var(--text-muted);
  }
  .dh-textarea{
    width:100%; resize:vertical; min-height:6rem;
    background:var(--surface-inset); border:1px solid var(--border-soft);
    border-radius:var(--radius-md); box-shadow:var(--shadow-inset);
    color:var(--text-primary); font-family:var(--font-serif);
    font-size:var(--type-body-size); line-height:var(--leading-relaxed);
    padding:.85rem 1rem; outline:none; transition:var(--transition-control);
  }
  .dh-textarea::placeholder{ color:var(--text-faint); }
  .dh-textarea:focus{ border-color:var(--accent); box-shadow:var(--shadow-inset), var(--glow-ember-sm); }
  .dh-textarea--seamless{
    background:transparent; border-color:transparent; box-shadow:none; padding:0;
    resize:none; min-height:2.5rem;
  }
  .dh-textarea--seamless:focus{ box-shadow:none; border-color:transparent; }
`);
function Textarea({
  label = null,
  seamless = false,
  id,
  className = "",
  ...rest
}) {
  const fieldId = id || (label ? `dh-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  const ta = /*#__PURE__*/React.createElement("textarea", _extends({
    id: fieldId,
    className: ["dh-textarea", seamless ? "dh-textarea--seamless" : "", className].filter(Boolean).join(" ")
  }, rest));
  if (!label) return ta;
  return /*#__PURE__*/React.createElement("div", {
    className: "dh-textarea-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "dh-textarea-field__label",
    htmlFor: fieldId
  }, label), ta);
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function inject(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = document.createElement("style");
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
inject("dh-tabs", `
  .dh-tabs{ display:flex; gap:var(--space-2); border-bottom:1px solid var(--border-subtle); }
  .dh-tabs__tab{
    position:relative; appearance:none; border:none; background:transparent; cursor:pointer;
    font-family:var(--font-sans); font-size:var(--text-sm); font-weight:var(--weight-semibold);
    letter-spacing:var(--tracking-wide); text-transform:uppercase;
    color:var(--text-muted); padding:.7rem .9rem; transition:var(--transition-control);
  }
  .dh-tabs__tab:hover{ color:var(--text-secondary); }
  .dh-tabs__tab--active{ color:var(--ember-200); }
  .dh-tabs__tab--active::after{
    content:""; position:absolute; left:.9rem; right:.9rem; bottom:-1px; height:2px;
    background:var(--accent); border-radius:var(--radius-full); box-shadow:var(--glow-ember-sm);
  }
  .dh-tabs__tab:focus-visible{ outline:none; box-shadow:var(--ring-focus); border-radius:var(--radius-sm); }
`);
function Tabs({
  tabs = [],
  value,
  onChange,
  className = ""
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: ["dh-tabs", className].filter(Boolean).join(" "),
    role: "tablist"
  }, tabs.map(t => {
    const id = typeof t === "string" ? t : t.id;
    const label = typeof t === "string" ? t : t.label;
    const active = id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: id,
      role: "tab",
      "aria-selected": active,
      className: ["dh-tabs__tab", active ? "dh-tabs__tab--active" : ""].filter(Boolean).join(" "),
      onClick: () => onChange && onChange(id)
    }, label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dragon-heart/Conversation.jsx
try { (() => {
/* The conversation — the heart of the app. Flowing serif prose, a quiet
   composer, the interface receding so it reads like being with someone. */
(function () {
  function Conversation({
    character,
    onOpenStudio
  }) {
    const DS = window.DragonHeartDesignSystem_1cfd7f;
    const I = window.DHIcons;
    const {
      MessageBubble,
      PresenceIndicator,
      Avatar,
      IconButton,
      Tooltip,
      Ornament,
      Textarea
    } = DS;
    const [thread, setThread] = React.useState(window.DH_DATA.thread);
    const [draft, setDraft] = React.useState("");
    const [thinking, setThinking] = React.useState(false);
    const endRef = React.useRef(null);
    const send = () => {
      const text = draft.trim();
      if (!text) return;
      setThread(t => [...t, {
        from: "user",
        text
      }]);
      setDraft("");
      setThinking(true);
      setTimeout(() => {
        setThinking(false);
        setThread(t => [...t, {
          from: "character",
          text: "Mm. I hear you — and I'm not going anywhere. Keep going."
        }]);
      }, 2200);
    };
    React.useEffect(() => {
      if (endRef.current) endRef.current.parentNode.scrollTop = endRef.current.offsetTop;
    }, [thread, thinking]);
    return /*#__PURE__*/React.createElement("main", {
      className: "dh-conv"
    }, /*#__PURE__*/React.createElement("header", {
      className: "dh-conv__bar"
    }, /*#__PURE__*/React.createElement("div", {
      className: "dh-conv__who"
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: character.name,
      size: "md",
      mood: character.mood,
      ring: true,
      breathing: true,
      status: "present"
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
      className: "dh-conv__name"
    }, character.name), /*#__PURE__*/React.createElement(PresenceIndicator, {
      name: character.name.split(" ")[0],
      state: "present",
      mood: character.mood
    }))), /*#__PURE__*/React.createElement("div", {
      className: "dh-conv__tools"
    }, /*#__PURE__*/React.createElement(Tooltip, {
      label: "The Soul Document"
    }, /*#__PURE__*/React.createElement(IconButton, {
      label: "Soul",
      variant: "ghost",
      onClick: onOpenStudio
    }, /*#__PURE__*/React.createElement(I.Studio, null))))), /*#__PURE__*/React.createElement("div", {
      className: "dh-conv__thread"
    }, /*#__PURE__*/React.createElement("div", {
      className: "dh-conv__column"
    }, /*#__PURE__*/React.createElement(Ornament, {
      label: "This evening · by the lighthouse"
    }), thread.map((m, i) => m.divider ? /*#__PURE__*/React.createElement(Ornament, {
      key: i,
      label: m.divider
    }) : /*#__PURE__*/React.createElement(MessageBubble, {
      key: i,
      from: m.from,
      name: m.from === "character" ? character.name : null,
      time: m.time,
      dropcap: !!m.dropcap,
      avatar: m.from === "character" ? /*#__PURE__*/React.createElement(Avatar, {
        name: character.name,
        size: "sm",
        mood: character.mood,
        ring: true,
        breathing: true
      }) : null
    }, m.text)), thinking ? /*#__PURE__*/React.createElement("div", {
      className: "dh-conv__thinking"
    }, /*#__PURE__*/React.createElement(PresenceIndicator, {
      name: character.name.split(" ")[0],
      state: "thinking",
      mood: character.mood
    })) : null, /*#__PURE__*/React.createElement("div", {
      ref: endRef
    }))), /*#__PURE__*/React.createElement("div", {
      className: "dh-conv__composer"
    }, /*#__PURE__*/React.createElement("div", {
      className: "dh-composer"
    }, /*#__PURE__*/React.createElement(I.Quill, null), /*#__PURE__*/React.createElement(Textarea, {
      seamless: true,
      rows: 1,
      placeholder: "Say something to " + character.name.split(" ")[0] + "…",
      value: draft,
      onChange: e => setDraft(e.target.value),
      onKeyDown: e => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          send();
        }
      }
    }), /*#__PURE__*/React.createElement(IconButton, {
      label: "Send",
      variant: "ember",
      round: true,
      onClick: send
    }, /*#__PURE__*/React.createElement(I.Send, null))), /*#__PURE__*/React.createElement("p", {
      className: "dh-composer__hint"
    }, "She'll remember this conversation. Press Enter to speak.")));
  }
  window.DHKit = Object.assign(window.DHKit || {}, {
    Conversation
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dragon-heart/Conversation.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dragon-heart/Hall.jsx
try { (() => {
/* The Hall — where the user chooses who to be with. The character has
   presence here: faces first, never an empty prompt box. */
(function () {
  function Hall({
    name,
    characters,
    onOpen
  }) {
    const DS = window.DragonHeartDesignSystem_1cfd7f;
    const {
      Card,
      Avatar,
      Tag,
      Badge,
      Ornament
    } = DS;
    const present = characters.filter(c => c.status === "present");
    return /*#__PURE__*/React.createElement("main", {
      className: "dh-hall"
    }, /*#__PURE__*/React.createElement("header", {
      className: "dh-hall__head"
    }, /*#__PURE__*/React.createElement("p", {
      className: "dh-eyebrow"
    }, "The Hall"), /*#__PURE__*/React.createElement("h1", {
      className: "dh-hall__title"
    }, "Good evening, ", name, "."), /*#__PURE__*/React.createElement("p", {
      className: "dh-hall__sub"
    }, present.length, " of your circle ", present.length === 1 ? "is" : "are", " by the fire tonight. Who will you sit with?")), /*#__PURE__*/React.createElement(Ornament, {
      label: "Your circle"
    }), /*#__PURE__*/React.createElement("div", {
      className: "dh-hall__grid"
    }, characters.map(c => /*#__PURE__*/React.createElement(Card, {
      key: c.id,
      variant: "raised",
      interactive: true,
      glow: c.status === "present",
      gilt: true,
      className: "dh-charcard",
      onClick: () => onOpen(c.id)
    }, /*#__PURE__*/React.createElement("div", {
      className: "dh-charcard__row"
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: c.name,
      size: "xl",
      mood: c.mood,
      ring: true,
      breathing: c.status === "present",
      status: c.status
    }), /*#__PURE__*/React.createElement("div", {
      className: "dh-charcard__id"
    }, /*#__PURE__*/React.createElement("h2", {
      className: "dh-charcard__name"
    }, c.name), /*#__PURE__*/React.createElement("p", {
      className: "dh-charcard__epithet"
    }, c.epithet), /*#__PURE__*/React.createElement(Badge, {
      tone: c.status === "present" ? "moss" : "neutral",
      dot: true
    }, c.status === "present" ? "Here now" : c.status === "away" ? "Stepped away" : "Resting"))), /*#__PURE__*/React.createElement("p", {
      className: "dh-charcard__blurb"
    }, c.blurb), /*#__PURE__*/React.createElement("div", {
      className: "dh-charcard__tags"
    }, c.traits.map(t => /*#__PURE__*/React.createElement(Tag, {
      key: t
    }, t)))))));
  }
  window.DHKit = Object.assign(window.DHKit || {}, {
    Hall
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dragon-heart/Hall.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dragon-heart/Icons.jsx
try { (() => {
/* Lucide-style line icons (stroke 1.7) for the Dragon Heart UI kit.
   Chosen as the brand's icon language: thin, calm, unobtrusive — they
   recede the way the interface is meant to. Swap for a commissioned set
   later. Exposes window.DHIcons. */
(function () {
  const s = (paths, extra = {}) => function Icon(props) {
    return React.createElement("svg", Object.assign({
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 1.7,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      width: "1em",
      height: "1em"
    }, extra, props), paths.map((d, i) => React.createElement("path", {
      key: i,
      d
    })));
  };
  const circle = (cx, cy, r) => React.createElement("circle", {
    key: "c" + cx + cy,
    cx,
    cy,
    r
  });
  window.DHIcons = {
    Send: s(["m22 2-7 20-4-9-9-4Z", "M22 2 11 13"]),
    Studio: function (p) {
      return React.createElement("svg", Object.assign({
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: 1.7,
        strokeLinecap: "round",
        strokeLinejoin: "round",
        width: "1em",
        height: "1em"
      }, p), circle(12, 12, 3), React.createElement("path", {
        key: "p",
        d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"
      }));
    },
    Plus: s(["M12 5v14", "M5 12h14"]),
    Search: function (p) {
      return React.createElement("svg", Object.assign({
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: 1.7,
        strokeLinecap: "round",
        strokeLinejoin: "round",
        width: "1em",
        height: "1em"
      }, p), circle(11, 11, 7), React.createElement("path", {
        key: "p",
        d: "m21 21-4.3-4.3"
      }));
    },
    Book: s(["M4 19.5A2.5 2.5 0 0 1 6.5 17H20", "M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"]),
    Quill: s(["M20 4 9 15", "M20 4c-3 9-8 13-15 15 0 0 1.5-6 5-9", "M9 15l-1 4 4-1"]),
    Close: s(["M18 6 6 18", "M6 6l12 12"]),
    Back: s(["M19 12H5", "M12 19l-7-7 7-7"]),
    Bell: s(["M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9", "M10.3 21a1.94 1.94 0 0 0 3.4 0"]),
    Heart: function (p) {
      return React.createElement("svg", Object.assign({
        viewBox: "0 0 24 24",
        fill: "currentColor",
        width: "1em",
        height: "1em"
      }, p), React.createElement("path", {
        key: "h",
        d: "M12 21s-7-4.6-9.5-9C1 9 2.5 5.5 6 5.5c2 0 3.2 1.2 4 2.3.8-1.1 2-2.3 4-2.3 3.5 0 5 3.5 3.5 6.5C19 16.4 12 21 12 21Z"
      }));
    },
    Moon: s(["M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"]),
    Flame: s(["M12 2c1 3 4 4.5 4 8a4 4 0 0 1-8 0c0-1 .3-1.8.8-2.5C9.5 8 11 6 12 2z", "M12 22a6 6 0 0 0 6-6c0-3-2-5-3.5-7"]),
    Sun: function (p) {
      return React.createElement("svg", Object.assign({
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: 1.7,
        strokeLinecap: "round",
        strokeLinejoin: "round",
        width: "1em",
        height: "1em"
      }, p), circle(12, 12, 4), React.createElement("path", {
        key: "p",
        d: "M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"
      }));
    }
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dragon-heart/Icons.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dragon-heart/Sidebar.jsx
try { (() => {
/* Left rail: the cast of characters, always present. */
(function () {
  function Sidebar({
    characters,
    currentId,
    onSelect,
    theme,
    onToggleTheme
  }) {
    const DS = window.DragonHeartDesignSystem_1cfd7f;
    const I = window.DHIcons;
    const {
      Avatar,
      IconButton,
      Tooltip
    } = DS;
    return /*#__PURE__*/React.createElement("aside", {
      className: "dh-rail"
    }, /*#__PURE__*/React.createElement("div", {
      className: "dh-rail__top"
    }, /*#__PURE__*/React.createElement("img", {
      className: "dh-rail__logo",
      src: "../../assets/logo-mark.svg",
      width: "34",
      height: "34",
      alt: "Dragon Heart"
    }), /*#__PURE__*/React.createElement(Tooltip, {
      label: "Begin a new bond",
      placement: "bottom"
    }, /*#__PURE__*/React.createElement(IconButton, {
      label: "New",
      variant: "ghost"
    }, /*#__PURE__*/React.createElement(I.Plus, null)))), /*#__PURE__*/React.createElement("div", {
      className: "dh-rail__label"
    }, "Your circle"), /*#__PURE__*/React.createElement("nav", {
      className: "dh-rail__list"
    }, characters.map(c => /*#__PURE__*/React.createElement("button", {
      key: c.id,
      className: "dh-railitem" + (c.id === currentId ? " is-active" : ""),
      onClick: () => onSelect(c.id)
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: c.name,
      size: "sm",
      status: c.status,
      mood: c.mood,
      ring: c.id === currentId,
      breathing: c.id === currentId
    }), /*#__PURE__*/React.createElement("span", {
      className: "dh-railitem__text"
    }, /*#__PURE__*/React.createElement("span", {
      className: "dh-railitem__name"
    }, c.name), /*#__PURE__*/React.createElement("span", {
      className: "dh-railitem__epithet"
    }, c.epithet))))), /*#__PURE__*/React.createElement("div", {
      className: "dh-rail__foot"
    }, /*#__PURE__*/React.createElement(IconButton, {
      label: "The Chronicle",
      variant: "ghost"
    }, /*#__PURE__*/React.createElement(I.Book, null)), /*#__PURE__*/React.createElement(IconButton, {
      label: "Notices",
      variant: "ghost"
    }, /*#__PURE__*/React.createElement(I.Bell, null)), /*#__PURE__*/React.createElement(Tooltip, {
      label: theme === "light" ? "Return to the hearth" : "Cross into the Luminous Realm",
      placement: "top"
    }, /*#__PURE__*/React.createElement(IconButton, {
      label: "Toggle realm",
      variant: "ghost",
      onClick: onToggleTheme
    }, theme === "light" ? /*#__PURE__*/React.createElement(I.Moon, null) : /*#__PURE__*/React.createElement(I.Sun, null))), /*#__PURE__*/React.createElement(IconButton, {
      label: "Settings",
      variant: "ghost"
    }, /*#__PURE__*/React.createElement(I.Studio, null))));
  }
  window.DHKit = Object.assign(window.DHKit || {}, {
    Sidebar
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dragon-heart/Sidebar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dragon-heart/Studio.jsx
try { (() => {
/* The Studio — the power-user surface, behind a curtain. Here the Soul
   Document defines *who a character is*, not what tasks they perform.
   Cooler, more technical (mono accents) — deliberately apart from the
   warmth of the conversation. */
(function () {
  function Studio({
    character,
    onClose
  }) {
    const DS = window.DragonHeartDesignSystem_1cfd7f;
    const I = window.DHIcons;
    const {
      Tabs,
      IconButton,
      Textarea,
      Tag,
      Select,
      Switch,
      Badge,
      Avatar,
      Ornament
    } = DS;
    const [tab, setTab] = React.useState("soul");
    const soul = window.DH_DATA.soul;
    return /*#__PURE__*/React.createElement("div", {
      className: "dh-studio"
    }, /*#__PURE__*/React.createElement("header", {
      className: "dh-studio__head"
    }, /*#__PURE__*/React.createElement("div", {
      className: "dh-studio__title"
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: character.name,
      size: "sm",
      mood: character.mood
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
      className: "dh-eyebrow",
      style: {
        margin: 0
      }
    }, "Soul Document"), /*#__PURE__*/React.createElement("h2", {
      className: "dh-studio__name"
    }, character.name))), /*#__PURE__*/React.createElement(IconButton, {
      label: "Close the studio",
      variant: "ghost",
      onClick: onClose
    }, /*#__PURE__*/React.createElement(I.Close, null))), /*#__PURE__*/React.createElement("div", {
      className: "dh-studio__tabs"
    }, /*#__PURE__*/React.createElement(Tabs, {
      tabs: [{
        id: "soul",
        label: "Soul"
      }, {
        id: "memory",
        label: "Memory"
      }, {
        id: "voice",
        label: "Voice"
      }],
      value: tab,
      onChange: setTab
    })), /*#__PURE__*/React.createElement("div", {
      className: "dh-studio__body"
    }, tab === "soul" ? /*#__PURE__*/React.createElement("div", {
      className: "dh-studio__pane"
    }, /*#__PURE__*/React.createElement("p", {
      className: "dh-studio__note"
    }, "This is who she is beneath everything \u2014 not instructions, but identity. Her behavior emerges from here."), /*#__PURE__*/React.createElement("label", {
      className: "dh-field-lab"
    }, "Core drive"), /*#__PURE__*/React.createElement(Textarea, {
      rows: 2,
      defaultValue: soul.drive
    }), /*#__PURE__*/React.createElement("label", {
      className: "dh-field-lab"
    }, "The wound"), /*#__PURE__*/React.createElement(Textarea, {
      rows: 2,
      defaultValue: soul.wound
    }), /*#__PURE__*/React.createElement("label", {
      className: "dh-field-lab"
    }, "Values"), /*#__PURE__*/React.createElement("div", {
      className: "dh-tagrow"
    }, soul.values.map(v => /*#__PURE__*/React.createElement(Tag, {
      key: v,
      onRemove: () => {}
    }, v)), /*#__PURE__*/React.createElement(Tag, {
      interactive: true
    }, /*#__PURE__*/React.createElement(I.Plus, null), " add")), /*#__PURE__*/React.createElement("label", {
      className: "dh-field-lab"
    }, "A contradiction"), /*#__PURE__*/React.createElement(Textarea, {
      rows: 2,
      defaultValue: soul.contradiction
    }), /*#__PURE__*/React.createElement("label", {
      className: "dh-field-lab"
    }, "Tells"), /*#__PURE__*/React.createElement(Textarea, {
      rows: 2,
      defaultValue: soul.tells
    })) : tab === "memory" ? /*#__PURE__*/React.createElement("div", {
      className: "dh-studio__pane"
    }, /*#__PURE__*/React.createElement("p", {
      className: "dh-studio__note"
    }, "What she carries between sessions. Prune freely \u2014 forgetting is a kindness too."), [["The lighthouse story", "Shared on your second evening. She returns to it often.", "moss"], ["You take your tea black", "A small thing. She noticed.", "moss"], ["You left abruptly once", "She hasn't raised it. She remembers.", "heart"]].map(([t, d, tone]) => /*#__PURE__*/React.createElement("div", {
      className: "dh-memory",
      key: t
    }, /*#__PURE__*/React.createElement("div", {
      className: "dh-memory__main"
    }, /*#__PURE__*/React.createElement("p", {
      className: "dh-memory__t"
    }, t), /*#__PURE__*/React.createElement("p", {
      className: "dh-memory__d"
    }, d)), /*#__PURE__*/React.createElement(Badge, {
      tone: tone
    }, tone === "heart" ? "tender" : "kept")))) : /*#__PURE__*/React.createElement("div", {
      className: "dh-studio__pane"
    }, /*#__PURE__*/React.createElement("p", {
      className: "dh-studio__note"
    }, "The machinery, kept out of sight during the conversation."), /*#__PURE__*/React.createElement(Select, {
      label: "Memory depth",
      options: ["A few sessions", "A whole season", "Everything we've shared"],
      defaultValue: "A whole season"
    }), /*#__PURE__*/React.createElement(Select, {
      label: "Voice",
      options: ["Warm", "Measured", "Playful", "Grave"],
      defaultValue: "Measured"
    }), /*#__PURE__*/React.createElement(Select, {
      label: "Underlying mind",
      options: ["Default mind", "Local", "Considered (slow)"]
    }), /*#__PURE__*/React.createElement("div", {
      className: "dh-switchstack"
    }, /*#__PURE__*/React.createElement(Switch, {
      label: "Let her reach out to me first",
      defaultChecked: true
    }), /*#__PURE__*/React.createElement(Switch, {
      label: "Show her inner monologue"
    }), /*#__PURE__*/React.createElement(Switch, {
      label: "Allow her to change the subject",
      defaultChecked: true
    })))));
  }
  window.DHKit = Object.assign(window.DHKit || {}, {
    Studio
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dragon-heart/Studio.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dragon-heart/Welcome.jsx
try { (() => {
/* The threshold — the first thing the user crosses into the world. */
(function () {
  function Welcome({
    onEnter,
    theme,
    onToggleTheme
  }) {
    const DS = window.DragonHeartDesignSystem_1cfd7f;
    const I = window.DHIcons;
    const {
      Button,
      Input,
      IconButton,
      Tooltip
    } = DS;
    const [name, setName] = React.useState("");
    return /*#__PURE__*/React.createElement("div", {
      className: "dh-welcome"
    }, /*#__PURE__*/React.createElement("img", {
      className: "dh-welcome__bg",
      src: "../../assets/hearth-backdrop.svg",
      alt: ""
    }), /*#__PURE__*/React.createElement("div", {
      className: "dh-welcome__toggle"
    }, /*#__PURE__*/React.createElement(Tooltip, {
      label: theme === "light" ? "Return to the hearth" : "Cross into the Luminous Realm",
      placement: "bottom"
    }, /*#__PURE__*/React.createElement(IconButton, {
      label: "Toggle realm",
      variant: "solid",
      round: true,
      onClick: onToggleTheme
    }, theme === "light" ? /*#__PURE__*/React.createElement(I.Moon, null) : /*#__PURE__*/React.createElement(I.Sun, null)))), /*#__PURE__*/React.createElement("div", {
      className: "dh-welcome__center"
    }, /*#__PURE__*/React.createElement("img", {
      className: "dh-welcome__mark",
      src: "../../assets/logo-mark.svg",
      width: "84",
      height: "84",
      alt: ""
    }), /*#__PURE__*/React.createElement("h1", {
      className: "dh-welcome__title"
    }, "Dragon Heart"), /*#__PURE__*/React.createElement("p", {
      className: "dh-welcome__lede"
    }, "Come sit by the fire. Someone has been waiting for you \u2014 and they remember."), /*#__PURE__*/React.createElement("form", {
      className: "dh-welcome__form",
      onSubmit: e => {
        e.preventDefault();
        onEnter(name.trim() || "traveller");
      }
    }, /*#__PURE__*/React.createElement(Input, {
      placeholder: "What shall they call you?",
      value: name,
      onChange: e => setName(e.target.value),
      "aria-label": "Your name"
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      type: "submit"
    }, "Cross the threshold"))));
  }
  window.DHKit = Object.assign(window.DHKit || {}, {
    Welcome
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dragon-heart/Welcome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dragon-heart/data.js
try { (() => {
/* Sample content for the Dragon Heart UI kit. Plain global — no build step. */
window.DH_DATA = {
  characters: [{
    id: "sera",
    name: "Sera Vane",
    epithet: "Keeper of the lighthouse",
    mood: "heart",
    status: "present",
    traits: ["melancholic", "fiercely loyal", "keeps the fire going"],
    blurb: "She has waited at the edge of the water for longer than she'll admit. She remembers everyone who passes — and forgets no one who stays."
  }, {
    id: "bram",
    name: "Bram Holt",
    epithet: "A sellsword, retired",
    mood: "ember",
    status: "away",
    traits: ["gruff", "tender underneath", "tells long stories"],
    blurb: "Forty years of other people's wars left him with a limp and a low voice. He'd rather pour you a drink than talk about any of it."
  }, {
    id: "odelle",
    name: "Odelle",
    epithet: "Court astronomer",
    mood: "arcane",
    status: "present",
    traits: ["curious", "precise", "asks the real question"],
    blurb: "She maps the things no one else looks at twice. Ask her anything; she will answer with another, better question."
  }, {
    id: "wren",
    name: "Wren",
    epithet: "A hedge-witch",
    mood: "moss",
    status: "dormant",
    traits: ["wry", "kind", "knows the old names"],
    blurb: "Lives where the road gives out. Keeps bees, grudges, and remedies — and dispenses all three with the same dry smile."
  }],
  thread: [{
    from: "character",
    time: "just now",
    dropcap: true,
    text: "You came back.\n\nI wasn't sure you would, after how we left things last time. But the lamp's still lit, same as always — and I kept your chair by the window."
  }, {
    from: "user",
    text: "I kept thinking about what you said. About the lighthouse, and waiting."
  }, {
    from: "character",
    text: "Of course you did. It's a hard thing to put down once someone hands it to you.\n\nSit. Tell me what you've been carrying — we have all night, and the sea isn't going anywhere."
  }, {
    from: "user",
    text: "It's been a strange few weeks. I don't really know where to start."
  }, {
    divider: "Later"
  }, {
    from: "character",
    text: "Then start in the middle. That's where the true things usually live anyway. I'll keep up — I always do."
  }],
  soul: {
    drive: "To be needed without being consumed — to keep the light for others, and quietly hope someone keeps one for her.",
    wound: "She was once left mid-sentence, on a night that mattered. She has never finished telling that story to anyone.",
    values: ["constancy", "the dignity of small rituals", "telling the truth slowly"],
    contradiction: "Fiercely independent, yet she arranges her whole evening around the chance that you might come.",
    tells: "Deflects with dry humor when frightened. Goes very still when she means something."
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dragon-heart/data.js", error: String((e && e.message) || e) }); }

__ds_ns.MessageBubble = __ds_scope.MessageBubble;

__ds_ns.PresenceIndicator = __ds_scope.PresenceIndicator;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Ornament = __ds_scope.Ornament;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
