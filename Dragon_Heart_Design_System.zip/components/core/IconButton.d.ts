import * as React from "react";

/**
 * A compact, icon-only control for toolbars and the receding chrome of a
 * conversation. Always pass `label` for accessibility.
 */
export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Accessible name (also used as the tooltip title). */
  label: string;
  variant?: "ghost" | "solid" | "ember";
  size?: "sm" | "md" | "lg";
  /** Circular instead of soft-square. */
  round?: boolean;
  children?: React.ReactNode;
}

export function IconButton(props: IconButtonProps): JSX.Element;
