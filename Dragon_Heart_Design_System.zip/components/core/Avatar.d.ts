import * as React from "react";

/**
 * A character's face — the first thing a user sees, and the carrier of
 * *presence*. Falls back to a serif monogram when no portrait is set.
 * Use `breathing` on the character the user is currently with so the
 * presence ring slowly pulses, like someone listening.
 *
 * @startingPoint section="Core" subtitle="Character avatars with presence ring & mood" viewport="700x200"
 */
export interface AvatarProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Portrait image URL. Omit for a monogram derived from `name`. */
  src?: string | null;
  /** Character name — used for the monogram and the image alt text. */
  name?: string;
  size?: "xs" | "sm" | "md" | "lg" | "xl" | "2xl" | string;
  /** Tints the presence ring / glow to a character's emotional register. */
  mood?: "ember" | "heart" | "moss" | "arcane" | string;
  /** Show the colored presence ring. */
  ring?: boolean;
  /** Slowly pulse the ring — the character is here and attentive. */
  breathing?: boolean;
  /** Corner status pip. */
  status?: "none" | "present" | "away" | "dormant";
}

export function Avatar(props: AvatarProps): JSX.Element;
