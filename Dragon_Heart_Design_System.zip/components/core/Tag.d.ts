import * as React from "react";

/**
 * A soft chip for traits, themes, and inside-references — the texture of
 * who a character is and what a relationship is made of.
 */
export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  icon?: React.ReactNode;
  selected?: boolean;
  /** Hover affordance for filter/toggle use. */
  interactive?: boolean;
  /** Show a remove (×) button and handle its click. */
  onRemove?: React.MouseEventHandler<HTMLButtonElement>;
  children?: React.ReactNode;
}

export function Tag(props: TagProps): JSX.Element;
