Icon-only control for receding toolbar chrome — pass `label` for accessibility.

```jsx
<IconButton label="Settings" variant="ghost"><GearIcon/></IconButton>
<IconButton label="Send" variant="ember" round><SendIcon/></IconButton>
```

Variants: `ghost` (default, near-invisible until hover), `solid` (carded), `ember` (glowing accent). Sizes `sm | md | lg`. `round` for circular.
