Warm surface container for grouping content; `parchment` evokes a physical letter, `glow` marks the active element.

```jsx
<Card>Standard well</Card>
<Card variant="raised" interactive>A character to choose</Card>
<Card variant="parchment">Dearest friend, …</Card>
<Card glow gilt>The one you're with now</Card>
```

Props: `variant` (default | raised | parchment), `padded`, `interactive` (hover lift), `glow`, `gilt`.
