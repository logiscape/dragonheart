import * as React from "react";

/**
 * An illuminated-manuscript divider: a gilt rule with a centered fleuron
 * (or a small diamond) and an optional small-caps label. Use to mark the
 * passage of time, a new chapter of a conversation, or a section break.
 */
export interface OrnamentProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Optional small-caps label beside the mark (e.g. "Later that evening"). */
  label?: string | null;
  mark?: "fleuron" | "diamond";
}

export function Ornament(props: OrnamentProps): JSX.Element;
