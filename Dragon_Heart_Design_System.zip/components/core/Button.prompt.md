Ember-warm action button — the primary way a user commits to something; use `heart` for emotional or relationship-defining actions.

```jsx
<Button variant="primary" onClick={begin}>Begin</Button>
<Button variant="heart" leftIcon={<HeartIcon/>}>Stay a while</Button>
<Button variant="secondary" size="sm">Not now</Button>
<Button variant="ghost">Dismiss</Button>
```

Variants: `primary` (ember fill, glows on hover), `heart` (garnet, for commitment moments), `secondary` (gilt outline), `ghost` (quiet text). Sizes `sm | md | lg`. Props: `block`, `pill`, `leftIcon`, `rightIcon`, `disabled`. Buttons use the UI sans so they recede beneath the serif voice.
