import * as React from "react";

/**
 * Small uppercase status label. Tones map to the palette's emotional
 * registers; `dot` prefixes a status indicator.
 */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: "neutral" | "ember" | "heart" | "moss" | "arcane";
  /** Filled instead of soft-tinted. */
  solid?: boolean;
  dot?: boolean;
  children?: React.ReactNode;
}

export function Badge(props: BadgeProps): JSX.Element;
