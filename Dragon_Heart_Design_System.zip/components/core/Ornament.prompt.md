Illuminated divider — a gilt rule with a centered fleuron, optionally labelled. Marks time passing or a new chapter in a conversation.

```jsx
<Ornament />
<Ornament label="Later that evening" />
<Ornament mark="diamond" label="Chapter II" />
```

Props: `label`, `mark` (fleuron | diamond).
