import * as React from "react";

/**
 * Primary action control for Dragon Heart. Ember-filled by default; use
 * `heart` for emotional / commitment moments, and quieter variants for
 * chrome that should recede.
 *
 * @startingPoint section="Core" subtitle="Ember, heart, secondary & ghost buttons" viewport="700x180"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual weight. */
  variant?: "primary" | "heart" | "secondary" | "ghost";
  size?: "sm" | "md" | "lg";
  /** Stretch to fill the container width. */
  block?: boolean;
  /** Fully rounded pill shape. */
  pill?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  disabled?: boolean;
  children?: React.ReactNode;
}

export function Button(props: ButtonProps): JSX.Element;
