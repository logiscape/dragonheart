Soft chip for character traits, themes, and shared references.

```jsx
<Tag>melancholic</Tag>
<Tag interactive selected>fiercely loyal</Tag>
<Tag onRemove={drop}>the lighthouse story</Tag>
```

Props: `icon`, `selected`, `interactive` (hover affordance), `onRemove` (shows × button).
