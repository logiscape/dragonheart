import * as React from "react";

/**
 * Surface container. `parchment` for letter / manuscript moments, `glow`
 * to draw warmth toward an active element, `gilt` for an illuminated top edge.
 *
 * @startingPoint section="Core" subtitle="Card surfaces — dark, parchment, glow" viewport="700x260"
 */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "default" | "raised" | "parchment";
  /** Apply standard internal padding. */
  padded?: boolean;
  /** Lift + gilt border on hover. */
  interactive?: boolean;
  /** Soft ember glow (use for the focused/active card). */
  glow?: boolean;
  /** Illuminated gilt edge fading down from the top. */
  gilt?: boolean;
  children?: React.ReactNode;
}

export function Card(props: CardProps): JSX.Element;
