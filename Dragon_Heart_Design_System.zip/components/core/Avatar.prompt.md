A character's face and the carrier of *presence* — the centerpiece of Dragon Heart's "a person, not a prompt" metaphor. Monogram fallback when no portrait exists.

```jsx
<Avatar name="Sera Vane" status="present" />
<Avatar src={portrait} name="Sera Vane" size="xl" breathing mood="heart" />
```

Props: `src`, `name`, `size` (xs–2xl or any CSS length), `mood` (ember | heart | moss | arcane), `ring`, `breathing` (slow pulse for the active character), `status` (present | away | dormant). Use `breathing` only on the character the user is currently with.
