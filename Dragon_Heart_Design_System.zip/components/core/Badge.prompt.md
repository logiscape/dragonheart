Small uppercase status label in the palette's emotional tones.

```jsx
<Badge tone="ember" dot>Present</Badge>
<Badge tone="moss">Remembered</Badge>
<Badge tone="heart" solid>Bonded</Badge>
```

Tones: `neutral | ember | heart | moss | arcane`. `solid` for a filled chip, `dot` for a leading status dot.
