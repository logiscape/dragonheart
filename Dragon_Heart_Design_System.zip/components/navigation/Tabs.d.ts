import * as React from "react";

export interface TabItem {
  id: string;
  label: React.ReactNode;
}

/**
 * Underlined tab strip with a glowing ember indicator. Controlled — owns no
 * state. Used inside the studio to switch between Soul, Memory, and Voice.
 */
export interface TabsProps {
  /** Tab definitions (or plain strings used as both id and label). */
  tabs: (string | TabItem)[];
  value: string;
  onChange?: (id: string) => void;
  className?: string;
}

export function Tabs(props: TabsProps): JSX.Element;
