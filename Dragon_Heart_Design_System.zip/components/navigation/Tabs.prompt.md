Underlined tab strip with a glowing ember indicator — controlled.

```jsx
const [tab, setTab] = React.useState("soul");
<Tabs tabs={[{id:"soul",label:"Soul"},{id:"memory",label:"Memory"},{id:"voice",label:"Voice"}]} value={tab} onChange={setTab} />
```

Props: `tabs` (string[] or {id,label}[]), `value`, `onChange`.
