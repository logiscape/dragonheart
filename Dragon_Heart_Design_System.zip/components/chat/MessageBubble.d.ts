import * as React from "react";

/**
 * A single turn of conversation. The character's words flow as serif prose
 * with no bubble — the interface recedes so it reads like a letter, not a
 * chat log. The user's words sit in a quiet right-aligned well. This is the
 * core expression of Dragon Heart's "talking to a person" metaphor.
 *
 * @startingPoint section="Conversation" subtitle="Character & user message turns" viewport="700x320"
 */
export interface MessageBubbleProps {
  from?: "character" | "user";
  /** Character name shown above their words. */
  name?: string | null;
  time?: string | null;
  /** Pass an <Avatar> to show beside the turn. */
  avatar?: React.ReactNode;
  /** Illuminated drop-cap on the first paragraph (character only). */
  dropcap?: boolean;
  /** String children are split on blank lines into paragraphs. */
  children?: React.ReactNode;
  className?: string;
}

export function MessageBubble(props: MessageBubbleProps): JSX.Element;
