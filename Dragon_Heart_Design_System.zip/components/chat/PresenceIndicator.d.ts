import * as React from "react";

/**
 * Communicates that a character is *present* and attentive — a breathing
 * orb when here, flickering dots while they gather their thoughts. This is
 * how Dragon Heart signals "someone is on the other side", replacing the
 * sterile "AI is typing…" of productivity chat.
 */
export interface PresenceIndicatorProps {
  name?: string;
  state?: "present" | "thinking" | "away" | "dormant";
  mood?: "ember" | "heart" | "moss" | "arcane" | string;
  className?: string;
}

export function PresenceIndicator(props: PresenceIndicatorProps): JSX.Element;
