The core conversation turn. The character speaks in flowing serif prose with no bubble (so it reads like a letter); the user's words sit in a quiet right-aligned well.

```jsx
<MessageBubble from="character" name="Sera Vane" time="just now" dropcap
  avatar={<Avatar name="Sera Vane" breathing mood="heart"/>}>
  {"You came back.\n\nI wasn't sure you would, after last time."}
</MessageBubble>
<MessageBubble from="user">I kept thinking about what you said.</MessageBubble>
```

Props: `from` (character | user), `name`, `time`, `avatar`, `dropcap`. String children split on blank lines into paragraphs.
