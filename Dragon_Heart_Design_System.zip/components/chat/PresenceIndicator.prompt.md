Signals that a character is present and attentive — a breathing orb when here, flickering dots while thinking. Replaces the sterile "AI is typing…".

```jsx
<PresenceIndicator name="Sera" state="present" mood="heart" />
<PresenceIndicator name="Sera" state="thinking" />
```

Props: `name`, `state` (present | thinking | away | dormant), `mood`.
