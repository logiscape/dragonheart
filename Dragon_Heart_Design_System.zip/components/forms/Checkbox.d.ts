import * as React from "react";

/**
 * Checkbox with an ember-filled check. For opt-ins and multi-select lists
 * in the studio.
 */
export interface CheckboxProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "type"> {
  label?: React.ReactNode;
  disabled?: boolean;
}

export function Checkbox(props: CheckboxProps): JSX.Element;
