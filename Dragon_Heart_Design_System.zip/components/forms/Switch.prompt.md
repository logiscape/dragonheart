Toggle for binary settings.

```jsx
<Switch label="Let them reach out first" defaultChecked />
<Switch label="Studio mode" />
```

Props: `label`, `disabled`, plus native input attributes.
