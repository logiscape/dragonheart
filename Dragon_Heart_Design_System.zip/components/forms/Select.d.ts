import * as React from "react";

export interface SelectOption {
  value: string;
  label: string;
}

/**
 * Styled native select for studio settings — model, voice, memory depth.
 * A power-user control, so it lives in the studio rather than the
 * conversation.
 */
export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string | null;
  /** Convenience: pass options instead of <option> children. */
  options?: (string | SelectOption)[];
  children?: React.ReactNode;
}

export function Select(props: SelectProps): JSX.Element;
