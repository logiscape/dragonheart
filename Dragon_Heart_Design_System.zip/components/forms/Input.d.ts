import * as React from "react";

/**
 * Single-line text field. A sunken parchment-dark well that warms to a
 * gilt glow on focus. Body text is set in the reading serif, so what a
 * user types feels like writing, not data entry.
 */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string | null;
  hint?: string | null;
  /** Error message; overrides hint and reddens the border. */
  error?: string | null;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export function Input(props: InputProps): JSX.Element;
