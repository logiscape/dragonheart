import * as React from "react";

/**
 * Multi-line serif field for longer writing — letters, the composer, and
 * the Soul Document's prose. `seamless` strips the chrome so it can sit
 * invisibly inside a composer or card.
 */
export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string | null;
  /** Remove background/border/padding to embed in a custom container. */
  seamless?: boolean;
}

export function Textarea(props: TextareaProps): JSX.Element;
