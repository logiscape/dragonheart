Styled native select for studio settings.

```jsx
<Select label="Memory depth" options={["A few sessions","A season","Everything"]} />
<Select options={[{value:"gpt",label:"Default mind"},{value:"local",label:"Local"}]} />
```

Props: `label`, `options` (string[] or {value,label}[]) or `<option>` children, plus native select attributes.
