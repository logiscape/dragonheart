Multi-line serif field for letters, the composer, and Soul Document prose.

```jsx
<Textarea label="A letter" placeholder="Dearest…" rows={5} />
<Textarea seamless placeholder="Say something…" />
```

Props: `label`, `seamless` (strips chrome for embedding), plus native textarea attributes.
