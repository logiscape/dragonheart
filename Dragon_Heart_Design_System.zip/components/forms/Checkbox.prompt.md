Checkbox with an ember-filled check.

```jsx
<Checkbox label="Let them remember this" defaultChecked />
<Checkbox label="Disabled" disabled />
```

Props: `label`, `disabled`, plus native input attributes (`checked`, `onChange`, …).
