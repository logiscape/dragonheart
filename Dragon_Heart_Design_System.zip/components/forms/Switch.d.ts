import * as React from "react";

/**
 * Toggle for binary settings — "studio mode", presence notifications,
 * whether a character may reach out first.
 */
export interface SwitchProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "type"> {
  label?: React.ReactNode;
  disabled?: boolean;
}

export function Switch(props: SwitchProps): JSX.Element;
