Single-line text field — a sunken well that warms to a gilt glow on focus; typed text is serif, so input feels like writing.

```jsx
<Input label="Their name" placeholder="What shall I call you?" />
<Input label="Seal" error="That phrase isn't right" leftIcon={<KeyIcon/>} />
```

Props: `label`, `hint`, `error`, `leftIcon`, `rightIcon`, plus all native input attributes.
