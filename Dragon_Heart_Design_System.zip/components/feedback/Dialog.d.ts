import * as React from "react";

/**
 * Centered modal over a blurred scrim, crowned with a thin ember rule.
 * Reserved for moments of weight — saying goodbye, beginning anew,
 * confirming something irreversible.
 */
export interface DialogProps {
  open: boolean;
  title?: React.ReactNode;
  description?: React.ReactNode;
  onClose?: () => void;
  /** Footer action row (usually Buttons). */
  footer?: React.ReactNode;
  children?: React.ReactNode;
}

export function Dialog(props: DialogProps): JSX.Element | null;
