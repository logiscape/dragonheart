Centered modal over a blurred scrim — for moments of weight, not routine confirmations.

```jsx
<Dialog open={open} onClose={close}
  title="Part ways with Sera?"
  description="She'll remember this, even if you don't return for a while."
  footer={<><Button variant="ghost" onClick={close}>Stay</Button><Button variant="heart">Say goodbye</Button></>}
/>
```

Props: `open`, `title`, `description`, `onClose`, `footer`, `children`.
