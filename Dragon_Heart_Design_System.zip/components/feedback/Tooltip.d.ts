import * as React from "react";

/**
 * Hover/focus hint that wraps any trigger. Keep these to functional chrome
 * (icon buttons in the studio); the conversation itself stays unlabelled.
 */
export interface TooltipProps {
  label: React.ReactNode;
  placement?: "top" | "bottom";
  children: React.ReactNode;
  className?: string;
}

export function Tooltip(props: TooltipProps): JSX.Element;
