Quiet transient notice with a colored left edge — used sparingly.

```jsx
<Toast tone="moss" title="Kept" onClose={dismiss}>Sera will remember the lighthouse.</Toast>
<Toast tone="heart" title="Sera reached out" icon={<HeartIcon/>}>She left you a note.</Toast>
```

Props: `tone` (ember | heart | moss | arcane), `title`, `icon`, `onClose`, children (message).
