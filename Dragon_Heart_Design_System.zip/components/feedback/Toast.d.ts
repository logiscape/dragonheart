import * as React from "react";

/**
 * A quiet, transient notice with a colored left edge. Used sparingly — a
 * memory saved, a character reaching out — never for productivity chatter.
 */
export interface ToastProps extends React.HTMLAttributes<HTMLDivElement> {
  tone?: "ember" | "heart" | "moss" | "arcane";
  title?: React.ReactNode;
  icon?: React.ReactNode;
  onClose?: () => void;
  children?: React.ReactNode;
}

export function Toast(props: ToastProps): JSX.Element;
