Hover/focus hint wrapping any trigger — for functional chrome only.

```jsx
<Tooltip label="Open the studio"><IconButton label="Studio"><GearIcon/></IconButton></Tooltip>
<Tooltip label="Saved to memory" placement="bottom"><Badge tone="moss">Kept</Badge></Tooltip>
```

Props: `label`, `placement` (top | bottom), `children` (the trigger).
