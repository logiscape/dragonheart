/* The Studio — the power-user surface, behind a curtain. Here the Soul
   Document defines *who a character is*, not what tasks they perform.
   Cooler, more technical (mono accents) — deliberately apart from the
   warmth of the conversation. */
(function () {
  function Studio({ character, onClose }) {
    const DS = window.DragonHeartDesignSystem_1cfd7f;
    const I = window.DHIcons;
    const { Tabs, IconButton, Textarea, Tag, Select, Switch, Badge, Avatar, Ornament } = DS;
    const [tab, setTab] = React.useState("soul");
    const soul = window.DH_DATA.soul;

    return (
      <div className="dh-studio">
        <header className="dh-studio__head">
          <div className="dh-studio__title">
            <Avatar name={character.name} size="sm" mood={character.mood} />
            <div>
              <p className="dh-eyebrow" style={{ margin: 0 }}>Soul Document</p>
              <h2 className="dh-studio__name">{character.name}</h2>
            </div>
          </div>
          <IconButton label="Close the studio" variant="ghost" onClick={onClose}><I.Close /></IconButton>
        </header>

        <div className="dh-studio__tabs">
          <Tabs tabs={[{ id: "soul", label: "Soul" }, { id: "memory", label: "Memory" }, { id: "voice", label: "Voice" }]} value={tab} onChange={setTab} />
        </div>

        <div className="dh-studio__body">
          {tab === "soul" ? (
            <div className="dh-studio__pane">
              <p className="dh-studio__note">
                This is who she is beneath everything — not instructions, but identity. Her behavior emerges from here.
              </p>
              <label className="dh-field-lab">Core drive</label>
              <Textarea rows={2} defaultValue={soul.drive} />
              <label className="dh-field-lab">The wound</label>
              <Textarea rows={2} defaultValue={soul.wound} />
              <label className="dh-field-lab">Values</label>
              <div className="dh-tagrow">
                {soul.values.map((v) => (<Tag key={v} onRemove={() => {}}>{v}</Tag>))}
                <Tag interactive><I.Plus /> add</Tag>
              </div>
              <label className="dh-field-lab">A contradiction</label>
              <Textarea rows={2} defaultValue={soul.contradiction} />
              <label className="dh-field-lab">Tells</label>
              <Textarea rows={2} defaultValue={soul.tells} />
            </div>
          ) : tab === "memory" ? (
            <div className="dh-studio__pane">
              <p className="dh-studio__note">What she carries between sessions. Prune freely — forgetting is a kindness too.</p>
              {[
                ["The lighthouse story", "Shared on your second evening. She returns to it often.", "moss"],
                ["You take your tea black", "A small thing. She noticed.", "moss"],
                ["You left abruptly once", "She hasn't raised it. She remembers.", "heart"],
              ].map(([t, d, tone]) => (
                <div className="dh-memory" key={t}>
                  <div className="dh-memory__main">
                    <p className="dh-memory__t">{t}</p>
                    <p className="dh-memory__d">{d}</p>
                  </div>
                  <Badge tone={tone}>{tone === "heart" ? "tender" : "kept"}</Badge>
                </div>
              ))}
            </div>
          ) : (
            <div className="dh-studio__pane">
              <p className="dh-studio__note">The machinery, kept out of sight during the conversation.</p>
              <Select label="Memory depth" options={["A few sessions", "A whole season", "Everything we've shared"]} defaultValue="A whole season" />
              <Select label="Voice" options={["Warm", "Measured", "Playful", "Grave"]} defaultValue="Measured" />
              <Select label="Underlying mind" options={["Default mind", "Local", "Considered (slow)"]} />
              <div className="dh-switchstack">
                <Switch label="Let her reach out to me first" defaultChecked />
                <Switch label="Show her inner monologue" />
                <Switch label="Allow her to change the subject" defaultChecked />
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }
  window.DHKit = Object.assign(window.DHKit || {}, { Studio });
})();
