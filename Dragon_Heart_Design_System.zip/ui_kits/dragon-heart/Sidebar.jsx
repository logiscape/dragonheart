/* Left rail: the cast of characters, always present. */
(function () {
  function Sidebar({ characters, currentId, onSelect, theme, onToggleTheme }) {
    const DS = window.DragonHeartDesignSystem_1cfd7f;
    const I = window.DHIcons;
    const { Avatar, IconButton, Tooltip } = DS;
    return (
      <aside className="dh-rail">
        <div className="dh-rail__top">
          <img className="dh-rail__logo" src="../../assets/logo-mark.svg" width="34" height="34" alt="Dragon Heart" />
          <Tooltip label="Begin a new bond" placement="bottom">
            <IconButton label="New" variant="ghost"><I.Plus /></IconButton>
          </Tooltip>
        </div>

        <div className="dh-rail__label">Your circle</div>
        <nav className="dh-rail__list">
          {characters.map((c) => (
            <button
              key={c.id}
              className={"dh-railitem" + (c.id === currentId ? " is-active" : "")}
              onClick={() => onSelect(c.id)}
            >
              <Avatar name={c.name} size="sm" status={c.status} mood={c.mood} ring={c.id === currentId} breathing={c.id === currentId} />
              <span className="dh-railitem__text">
                <span className="dh-railitem__name">{c.name}</span>
                <span className="dh-railitem__epithet">{c.epithet}</span>
              </span>
            </button>
          ))}
        </nav>

        <div className="dh-rail__foot">
          <IconButton label="The Chronicle" variant="ghost"><I.Book /></IconButton>
          <IconButton label="Notices" variant="ghost"><I.Bell /></IconButton>
          <Tooltip label={theme === "light" ? "Return to the hearth" : "Cross into the Luminous Realm"} placement="top">
            <IconButton label="Toggle realm" variant="ghost" onClick={onToggleTheme}>
              {theme === "light" ? <I.Moon /> : <I.Sun />}
            </IconButton>
          </Tooltip>
          <IconButton label="Settings" variant="ghost"><I.Studio /></IconButton>
        </div>
      </aside>
    );
  }
  window.DHKit = Object.assign(window.DHKit || {}, { Sidebar });
})();
