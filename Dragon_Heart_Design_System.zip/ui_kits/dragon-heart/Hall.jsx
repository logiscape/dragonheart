/* The Hall — where the user chooses who to be with. The character has
   presence here: faces first, never an empty prompt box. */
(function () {
  function Hall({ name, characters, onOpen }) {
    const DS = window.DragonHeartDesignSystem_1cfd7f;
    const { Card, Avatar, Tag, Badge, Ornament } = DS;
    const present = characters.filter((c) => c.status === "present");
    return (
      <main className="dh-hall">
        <header className="dh-hall__head">
          <p className="dh-eyebrow">The Hall</p>
          <h1 className="dh-hall__title">Good evening, {name}.</h1>
          <p className="dh-hall__sub">
            {present.length} of your circle {present.length === 1 ? "is" : "are"} by the fire tonight. Who will you sit with?
          </p>
        </header>

        <Ornament label="Your circle" />

        <div className="dh-hall__grid">
          {characters.map((c) => (
            <Card key={c.id} variant="raised" interactive glow={c.status === "present"} gilt className="dh-charcard" onClick={() => onOpen(c.id)}>
              <div className="dh-charcard__row">
                <Avatar name={c.name} size="xl" mood={c.mood} ring breathing={c.status === "present"} status={c.status} />
                <div className="dh-charcard__id">
                  <h2 className="dh-charcard__name">{c.name}</h2>
                  <p className="dh-charcard__epithet">{c.epithet}</p>
                  <Badge tone={c.status === "present" ? "moss" : "neutral"} dot>
                    {c.status === "present" ? "Here now" : c.status === "away" ? "Stepped away" : "Resting"}
                  </Badge>
                </div>
              </div>
              <p className="dh-charcard__blurb">{c.blurb}</p>
              <div className="dh-charcard__tags">
                {c.traits.map((t) => (
                  <Tag key={t}>{t}</Tag>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </main>
    );
  }
  window.DHKit = Object.assign(window.DHKit || {}, { Hall });
})();
