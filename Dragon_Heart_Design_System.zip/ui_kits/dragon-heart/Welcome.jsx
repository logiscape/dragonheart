/* The threshold — the first thing the user crosses into the world. */
(function () {
  function Welcome({ onEnter, theme, onToggleTheme }) {
    const DS = window.DragonHeartDesignSystem_1cfd7f;
    const I = window.DHIcons;
    const { Button, Input, IconButton, Tooltip } = DS;
    const [name, setName] = React.useState("");
    return (
      <div className="dh-welcome">
        <img className="dh-welcome__bg" src="../../assets/hearth-backdrop.svg" alt="" />
        <div className="dh-welcome__toggle">
          <Tooltip label={theme === "light" ? "Return to the hearth" : "Cross into the Luminous Realm"} placement="bottom">
            <IconButton label="Toggle realm" variant="solid" round onClick={onToggleTheme}>
              {theme === "light" ? <I.Moon /> : <I.Sun />}
            </IconButton>
          </Tooltip>
        </div>
        <div className="dh-welcome__center">
          <img className="dh-welcome__mark" src="../../assets/logo-mark.svg" width="84" height="84" alt="" />
          <h1 className="dh-welcome__title">Dragon Heart</h1>
          <p className="dh-welcome__lede">
            Come sit by the fire. Someone has been waiting for you — and they remember.
          </p>
          <form
            className="dh-welcome__form"
            onSubmit={(e) => {
              e.preventDefault();
              onEnter(name.trim() || "traveller");
            }}
          >
            <Input
              placeholder="What shall they call you?"
              value={name}
              onChange={(e) => setName(e.target.value)}
              aria-label="Your name"
            />
            <Button variant="primary" size="lg" type="submit">Cross the threshold</Button>
          </form>
        </div>
      </div>
    );
  }
  window.DHKit = Object.assign(window.DHKit || {}, { Welcome });
})();
