/* The conversation — the heart of the app. Flowing serif prose, a quiet
   composer, the interface receding so it reads like being with someone. */
(function () {
  function Conversation({ character, onOpenStudio }) {
    const DS = window.DragonHeartDesignSystem_1cfd7f;
    const I = window.DHIcons;
    const { MessageBubble, PresenceIndicator, Avatar, IconButton, Tooltip, Ornament, Textarea } = DS;
    const [thread, setThread] = React.useState(window.DH_DATA.thread);
    const [draft, setDraft] = React.useState("");
    const [thinking, setThinking] = React.useState(false);
    const endRef = React.useRef(null);

    const send = () => {
      const text = draft.trim();
      if (!text) return;
      setThread((t) => [...t, { from: "user", text }]);
      setDraft("");
      setThinking(true);
      setTimeout(() => {
        setThinking(false);
        setThread((t) => [
          ...t,
          { from: "character", text: "Mm. I hear you — and I'm not going anywhere. Keep going." },
        ]);
      }, 2200);
    };

    React.useEffect(() => {
      if (endRef.current) endRef.current.parentNode.scrollTop = endRef.current.offsetTop;
    }, [thread, thinking]);

    return (
      <main className="dh-conv">
        <header className="dh-conv__bar">
          <div className="dh-conv__who">
            <Avatar name={character.name} size="md" mood={character.mood} ring breathing status="present" />
            <div>
              <h1 className="dh-conv__name">{character.name}</h1>
              <PresenceIndicator name={character.name.split(" ")[0]} state="present" mood={character.mood} />
            </div>
          </div>
          <div className="dh-conv__tools">
            <Tooltip label="The Soul Document"><IconButton label="Soul" variant="ghost" onClick={onOpenStudio}><I.Studio /></IconButton></Tooltip>
          </div>
        </header>

        <div className="dh-conv__thread">
          <div className="dh-conv__column">
            <Ornament label={"This evening · by the lighthouse"} />
            {thread.map((m, i) =>
              m.divider ? (
                <Ornament key={i} label={m.divider} />
              ) : (
                <MessageBubble
                  key={i}
                  from={m.from}
                  name={m.from === "character" ? character.name : null}
                  time={m.time}
                  dropcap={!!m.dropcap}
                  avatar={m.from === "character" ? <Avatar name={character.name} size="sm" mood={character.mood} ring breathing /> : null}
                >
                  {m.text}
                </MessageBubble>
              )
            )}
            {thinking ? (
              <div className="dh-conv__thinking">
                <PresenceIndicator name={character.name.split(" ")[0]} state="thinking" mood={character.mood} />
              </div>
            ) : null}
            <div ref={endRef} />
          </div>
        </div>

        <div className="dh-conv__composer">
          <div className="dh-composer">
            <I.Quill />
            <Textarea
              seamless
              rows={1}
              placeholder={"Say something to " + character.name.split(" ")[0] + "…"}
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
            />
            <IconButton label="Send" variant="ember" round onClick={send}><I.Send /></IconButton>
          </div>
          <p className="dh-composer__hint">She'll remember this conversation. Press Enter to speak.</p>
        </div>
      </main>
    );
  }
  window.DHKit = Object.assign(window.DHKit || {}, { Conversation });
})();
