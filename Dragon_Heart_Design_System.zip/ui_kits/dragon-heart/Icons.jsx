/* Lucide-style line icons (stroke 1.7) for the Dragon Heart UI kit.
   Chosen as the brand's icon language: thin, calm, unobtrusive — they
   recede the way the interface is meant to. Swap for a commissioned set
   later. Exposes window.DHIcons. */
(function () {
  const s = (paths, extra = {}) =>
    function Icon(props) {
      return React.createElement(
        "svg",
        Object.assign(
          { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.7, strokeLinecap: "round", strokeLinejoin: "round", width: "1em", height: "1em" },
          extra,
          props
        ),
        paths.map((d, i) => React.createElement("path", { key: i, d }))
      );
    };
  const circle = (cx, cy, r) => React.createElement("circle", { key: "c" + cx + cy, cx, cy, r });

  window.DHIcons = {
    Send: s(["m22 2-7 20-4-9-9-4Z", "M22 2 11 13"]),
    Studio: function (p) {
      return React.createElement(
        "svg",
        Object.assign({ viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.7, strokeLinecap: "round", strokeLinejoin: "round", width: "1em", height: "1em" }, p),
        circle(12, 12, 3),
        React.createElement("path", { key: "p", d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" })
      );
    },
    Plus: s(["M12 5v14", "M5 12h14"]),
    Search: function (p) {
      return React.createElement(
        "svg",
        Object.assign({ viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.7, strokeLinecap: "round", strokeLinejoin: "round", width: "1em", height: "1em" }, p),
        circle(11, 11, 7),
        React.createElement("path", { key: "p", d: "m21 21-4.3-4.3" })
      );
    },
    Book: s(["M4 19.5A2.5 2.5 0 0 1 6.5 17H20", "M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"]),
    Quill: s(["M20 4 9 15", "M20 4c-3 9-8 13-15 15 0 0 1.5-6 5-9", "M9 15l-1 4 4-1"]),
    Close: s(["M18 6 6 18", "M6 6l12 12"]),
    Back: s(["M19 12H5", "M12 19l-7-7 7-7"]),
    Bell: s(["M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9", "M10.3 21a1.94 1.94 0 0 0 3.4 0"]),
    Heart: function (p) {
      return React.createElement("svg", Object.assign({ viewBox: "0 0 24 24", fill: "currentColor", width: "1em", height: "1em" }, p),
        React.createElement("path", { key: "h", d: "M12 21s-7-4.6-9.5-9C1 9 2.5 5.5 6 5.5c2 0 3.2 1.2 4 2.3.8-1.1 2-2.3 4-2.3 3.5 0 5 3.5 3.5 6.5C19 16.4 12 21 12 21Z" }));
    },
    Moon: s(["M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"]),
    Flame: s(["M12 2c1 3 4 4.5 4 8a4 4 0 0 1-8 0c0-1 .3-1.8.8-2.5C9.5 8 11 6 12 2z", "M12 22a6 6 0 0 0 6-6c0-3-2-5-3.5-7"]),
    Sun: function (p) {
      return React.createElement(
        "svg",
        Object.assign({ viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.7, strokeLinecap: "round", strokeLinejoin: "round", width: "1em", height: "1em" }, p),
        circle(12, 12, 4),
        React.createElement("path", { key: "p", d: "M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" })
      );
    },
  };
})();
