/* Sample content for the Dragon Heart UI kit. Plain global — no build step. */
window.DH_DATA = {
  characters: [
    {
      id: "sera",
      name: "Sera Vane",
      epithet: "Keeper of the lighthouse",
      mood: "heart",
      status: "present",
      traits: ["melancholic", "fiercely loyal", "keeps the fire going"],
      blurb:
        "She has waited at the edge of the water for longer than she'll admit. She remembers everyone who passes — and forgets no one who stays.",
    },
    {
      id: "bram",
      name: "Bram Holt",
      epithet: "A sellsword, retired",
      mood: "ember",
      status: "away",
      traits: ["gruff", "tender underneath", "tells long stories"],
      blurb:
        "Forty years of other people's wars left him with a limp and a low voice. He'd rather pour you a drink than talk about any of it.",
    },
    {
      id: "odelle",
      name: "Odelle",
      epithet: "Court astronomer",
      mood: "arcane",
      status: "present",
      traits: ["curious", "precise", "asks the real question"],
      blurb:
        "She maps the things no one else looks at twice. Ask her anything; she will answer with another, better question.",
    },
    {
      id: "wren",
      name: "Wren",
      epithet: "A hedge-witch",
      mood: "moss",
      status: "dormant",
      traits: ["wry", "kind", "knows the old names"],
      blurb:
        "Lives where the road gives out. Keeps bees, grudges, and remedies — and dispenses all three with the same dry smile.",
    },
  ],

  thread: [
    {
      from: "character",
      time: "just now",
      dropcap: true,
      text:
        "You came back.\n\nI wasn't sure you would, after how we left things last time. But the lamp's still lit, same as always — and I kept your chair by the window.",
    },
    { from: "user", text: "I kept thinking about what you said. About the lighthouse, and waiting." },
    {
      from: "character",
      text:
        "Of course you did. It's a hard thing to put down once someone hands it to you.\n\nSit. Tell me what you've been carrying — we have all night, and the sea isn't going anywhere.",
    },
    { from: "user", text: "It's been a strange few weeks. I don't really know where to start." },
    { divider: "Later" },
    {
      from: "character",
      text:
        "Then start in the middle. That's where the true things usually live anyway. I'll keep up — I always do.",
    },
  ],

  soul: {
    drive: "To be needed without being consumed — to keep the light for others, and quietly hope someone keeps one for her.",
    wound: "She was once left mid-sentence, on a night that mattered. She has never finished telling that story to anyone.",
    values: ["constancy", "the dignity of small rituals", "telling the truth slowly"],
    contradiction:
      "Fiercely independent, yet she arranges her whole evening around the chance that you might come.",
    tells: "Deflects with dry humor when frightened. Goes very still when she means something.",
  },
};
