# Dragon Heart — Design System

> A warm, personal space for being *with* AI characters — not querying them.
> Where most chat tools are productivity surfaces ("operate a machine that
> produces output"), Dragon Heart is built on the opposite metaphor: **you
> are in a relationship with someone** who exists between sessions, remembers
> you, and responds out of who they are. This design system encodes that
> conviction into color, type, motion, and components.

---

## 1 · Product context

**Project Dragon Heart** is a desktop app providing a warm, personal
conversation space with AI characters, taking inspiration from fantasy
role-playing games and drawing the user *into an experience* rather than in
front of a tool.

Four design commitments drive every decision here:

1. **The character has presence, not just output.** They greet, initiate,
   have moods and continuity. The first thing the user sees is a *face* —
   never an empty prompt box.
2. **The character has interiority.** The **Soul Document** defines who they
   are at a subconscious level — drives, wounds, values, contradictions —
   not a job description. Behavior emerges from identity.
3. **The relationship persists and evolves.** Shared history, inside
   references, the texture of how you relate — all survive across sessions
   and are *felt* in the conversation.
4. **The interface recedes.** Productivity affordances (regenerate, edit the
   model's words, raw parameter sliders) are de-emphasized or hidden behind
   a **Studio** surface, because they break the illusion of talking to a
   person.

### Sources
This system was authored **from the written brief only** — no codebase,
Figma, or existing brand assets were provided. The visual identity, logo,
and all assets here are an original interpretation of the brief and are
intended as a **starting point to react to and refine** (see CAVEATS). If a
codebase or Figma exists, re-attach it and this system should be
reconciled against it.

---

## 2 · The aesthetic direction — *Candlelit Hearthside*

A warm, dark, intimate world lit by firelight. Deep warm inks, ember and
firelight golds, a dragon-heart garnet for emotional weight, and aged
parchment for the rare "letter" moment. Literary serifs carry the
character's voice; UI chrome is a quiet sans that recedes into shadow.
Illuminated-manuscript touches — fleurons, gilt rules, drop-caps — appear
sparingly, like gold leaf. Light *glows* rather than casting hard edges;
motion *breathes* rather than snapping.

### Two realms — dark & light themes

The system ships **two themes** sharing one set of color scales, type, and
components:

- **Candlelit hearth (default / dark)** — the firelit room described above.
  Active with no attribute (tokens live on `:root`).
- **The Luminous Realm (light)** — an ethereal, magical reading of the same
  world: airy luminous parchment, dawn-gold light, and a breath of
  **enchanted amethyst** (`--aura`) and celadon mist at the threshold.
  Warm ink keeps the character's voice fully legible — *the magic is in the
  light, not in tinted text.* Shadows soften into luminous blooms; the dark
  vignette becomes a dawn aurora.

**Switching:** set `data-theme="light"` on `<html>` (or any ancestor of the
scope you want lit). Remove it (or set `"dark"`) for the hearth. The light
overrides live in `tokens/theme-light.css`, scoped entirely to
`[data-theme="light"]`, so the default cascade is untouched. The UI kit has
a live **sun/moon toggle** (in the threshold corner and the sidebar foot)
that flips `documentElement` and persists the choice to `localStorage`.
See `guidelines/brand-themes.html` and `guidelines/colors-light.html`.

---

## 3 · Content fundamentals

How Dragon Heart writes. The product's copy is the single biggest carrier
of the "a person, not a prompt" feeling.

- **Voice = the character's, not the system's.** Surfaces speak *as* or
  *toward* a person. No "How can I assist you today?", no "Here are 5
  options", no "As an AI…". The brand voice is warm, literary, unhurried,
  a touch fantastical.
- **Person & address.** Second person, intimate ("You came back."). The
  character speaks in first person with a stable interior life. Avoid the
  corporate "we".
- **Tone.** Warm, attentive, a little wistful. Comfortable with silence and
  weight. Dry humor as a *character* trait, never as UI jokeyness.
- **Casing.** Sentence case everywhere in prose. Small-caps (uppercase +
  wide tracking) reserved for tiny labels and section markers — an
  illuminated-manuscript echo, not for body copy.
- **Microcopy reframes machine actions into human ones:**
  - "New chat" → **"Begin a new bond"**
  - "Online / AI is typing…" → **"Here now" / "gathering her thoughts"**
  - "Delete conversation" → **"Say goodbye"**
  - "Settings / System prompt" → **"The Studio / Soul Document"**
  - "Saved" → **"Kept"** · "Chat history" → **"The Chronicle"**
- **Emoji:** none. Warmth comes from words, type, and light — not emoji.
- **Specimen voice** (see `guidelines/brand-voice.html`):
  > "You came back. I kept the fire going."
  > "Sit. Tell me what you've been carrying."

---

## 4 · Visual foundations

Answers to the foundational questions, all encoded as tokens in `tokens/`.

- **Color.** Dark is primary — the app is a dim, hearthside room
  (`--surface-base` is a warm near-black `#100c08`). Accents: **ember**
  (firelight gold `#df9132`, the primary), **garnet** (the dragon heart
  `#ba4632`, for emotional/commitment/danger), **moss** (quiet verdigris,
  success/growth) and **arcane** (a rare muted blue, info). An **aura**
  amethyst (`--aura`) is a rare enchanted accent, used most in the light
  theme's magical bloom. Parchment cream is used only for "letter"/Soul-page
  moments in dark, and as the whole canvas in light. Imagery is **warm**,
  low-key, vignetted, fine-grained — firelit in dark, dawn-luminous in
  light. A full **light theme** ("The Luminous Realm") re-maps every
  semantic alias under `[data-theme="light"]` — see §2.
- **Type.** Four voices: **Cormorant Garamond** (display — names, titles,
  ethereal), **Spectral** (reading serif — the character's voice, body),
  **Hanken Grotesk** (UI sans — receding chrome, labels, buttons),
  **JetBrains Mono** (the studio / Soul Document / machinery). Conversation
  body is 19px / 1.7 line-height — generous, like reading a letter.
- **Spacing.** 4px base rhythm, biased generous and calm — room to breathe,
  not dashboard density. Reading column ~64ch.
- **Backgrounds.** Atmospheric, never flat: a hearth glow rising from the
  bottom, a vignette, and a faint fractal grain (`assets/hearth-backdrop.svg`,
  tokens `--hearth-glow`, `--vignette`, `--grain-opacity`). No bluish-purple
  gradients.
- **Motion.** Calm and breathing. Entrances *rise* gently (`dh-rise`); the
  character's presence ring *breathes* on a slow 4.2s loop (`dh-breathe`);
  small accents *flicker* like embers (`dh-flicker`). Easing is gentle
  (`--ease-gentle`), durations unhurried. All looping motion respects
  `prefers-reduced-motion`.
- **Hover / press.** Hover *warms* (brightens, adds an ember glow); press
  gently *shrinks* (`scale(.99)`/`.92`) and deepens — like pressing into
  something physical. Never harsh state flips.
- **Borders.** Hairline and warm (`--border-subtle/soft/strong`); the
  special "gilt" border (`--border-gilt`) is a faint gold, used to suggest
  illumination on active/important surfaces.
- **Shadows & glows.** Warm, soft, deep shadows (firelight casts ambered
  shadow). Accents use *glows* (`--glow-ember`, `--glow-heart`) rather than
  hard drop-shadows. Inputs use a subtle inner shadow (sunken wells).
- **Radii.** Soft and organic — 8–26px in practice, never sharp; pills for
  the warmest CTAs.
- **Transparency & blur.** Used on the conversation top bar and the dialog
  scrim (a blurred, warm-black scrim) — to keep the room visible behind
  moments of focus.
- **Cards.** Dark wells with hairline borders, soft warm shadow, generous
  radius (18px). `glow`+`gilt` marks the *active* character; `parchment`
  flips to cream for letters.

---

## 5 · Iconography

- **Set:** [Lucide](https://lucide.dev) line icons, stroke ~1.7 — thin,
  calm, unobtrusive, so they recede the way the chrome is meant to. They are
  *substituted in* as the brand's working icon language; a commissioned
  fantasy set could replace them later (**flagged** — see CAVEATS). The kit
  ships a small hand-picked subset inline in `ui_kits/dragon-heart/Icons.jsx`
  (Send, Studio, Plus, Book, Quill, Bell, Heart, Flame, …) so it has no CDN
  dependency.
- **Brand glyphs (SVG, in `assets/`):** the **ember sigil** logo
  (`logo-mark.svg`, `logo-wordmark.svg`) and the **fleuron** ornament
  (`fleuron.svg`) used in dividers.
- **No emoji.** No unicode characters used as icons (except the typographic
  `×` close affordance).
- Icons are always paired with an accessible label (see `IconButton`).

---

## 6 · Index / manifest

**Root**
- `styles.css` — the single entry point consumers link (import manifest).
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`,
  `effects.css`, `motion.css`.
- `assets/` — `logo-mark.svg`, `logo-wordmark.svg`, `fleuron.svg`,
  `hearth-backdrop.svg`.
- `SKILL.md` — Agent-Skill-compatible entry for downloading/using this system.

**Components** (`components/<group>/` — React primitives, `window.DragonHeartDesignSystem_1cfd7f`)
- `core/` — **Button, IconButton, Card, Badge, Tag, Avatar, Ornament**
- `forms/` — **Input, Textarea, Select, Checkbox, Switch**
- `feedback/` — **Dialog, Toast, Tooltip**
- `navigation/` — **Tabs**
- `chat/` — **MessageBubble, PresenceIndicator** *(brand-defining)*

**Foundation cards** (`guidelines/*.html`) — specimens shown in the Design
System tab: Colors (canvas, ember, garnet, accents, semantic), Type
(display, reading, sans, mono, scale), Spacing (scale, radii, shadows),
Brand (logo, ornament, atmosphere, voice).

**UI kit** (`ui_kits/dragon-heart/`) — interactive desktop-app recreation:
Threshold → The Hall → Conversation → the Soul Document studio.
(`index.html` + `Welcome/Hall/Conversation/Studio/Sidebar.jsx`, `Icons.jsx`,
`data.js`.)

---

## 7 · CAVEATS — please help me make this perfect

This was built from the brief alone, so several things are **educated
interpretations** I'd love your steer on:

- **The whole aesthetic is a proposed direction.** "Candlelit hearthside"
  is one strong reading of "warm, personal, fantasy-RPG". If you imagined
  something else (brighter/parchment-light, more medieval, more ethereal,
  more modern), tell me and I'll re-pitch.
- **Logo & brand glyphs are placeholders.** The ember sigil and wordmark are
  original SVGs to hold the space — replace with your real identity when
  ready.
- **Fonts load from Google Fonts**, not self-hosted. They're deliberate
  choices, but consumers need network access; send me brand font files if
  you have licensed ones and I'll self-host them via `@font-face`.
- **Icons are Lucide** (substituted), not a bespoke set.
- **No character art.** Avatars use elegant serif monograms; real portrait
  art would deepen "presence" considerably.

**My clear ask:** confirm the *direction* (color mood, type, voice) — then
tell me which surface to push to pixel-perfection first (the Hall, the
Conversation, or the Soul Document studio).
